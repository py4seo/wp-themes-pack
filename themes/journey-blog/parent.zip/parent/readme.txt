=== Journey Blog ===

Contributors: crimsonthemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, one-column, two-columns, custom-header, blog, entertainment, portfolio
Requires at least: 5.1
Requires PHP: 5.6
Tested up to: 6.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Journey Blog is a clean and minimal blog theme The perfect destination for every professional travel blogger and traveler is here! Journey Blog was designed for all modern adventure, who need to create personal blog site , travel blogger with simple and creative features and effects to make readers feel the pleasure of reading blog posts and articles. If you are a blogger and traveller, then it’s a perfect choice for you if you don’t need to have any experiment to setup your Wordpress personal blog, it’s super simple and easy to setup, you will get high quality, responsive, well crafted blog out of the box to make writers only focuses on writing content, and it has great typography to make your fans and followers focus on every word you write.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Journey Blog WordPress Theme, Copyright 2022 Crimson Themes
Journey Blog is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0.0 - Feb 16, 2023 =
* Initial release

= 1.0.1 - Mar 10, 2023 =
* Updated Customizer issue

== Theme Screenshot ==

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/428172

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/544714

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/606165

== Resources ==

Font Awesome
License: MIT
Source: https://fontawesome.com

normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal
License: MIT
Source: https://necolas.github.io/normalize.css/

Underscores, Copyright 2012-2017 Automattic
License: GPLv2 or later
Source: https://www.gnu.org/licenses/gpl-2.0.html