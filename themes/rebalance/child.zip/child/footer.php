<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Rebalance
 */
?>

			<footer id="colophon" class="site-footer" role="contentinfo">
				<div class="site-info">
                <p>Copyright &copy; <?php echo date('Y'); ?> | <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
				</div><!-- .site-info -->
			</footer><!-- #colophon -->

		</div><!-- .col-width -->
	</div><!-- #content -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>