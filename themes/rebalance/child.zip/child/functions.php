<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );



//Excerpt

function custom_excerpt_length($content) {
    global $post;
    $content = get_the_content();
    $trimmed_content = mb_substr($content, 0, 350) . '...';
    return $trimmed_content;
}

add_filter('the_excerpt', 'custom_excerpt_length', 10);
add_filter('get_the_excerpt', 'custom_excerpt_length', 10);
add_filter('wp_trim_excerpt', 'custom_excerpt_length', 10);


// Login error echo
function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');






// Remove the link from the logo on the login page
add_action('login_head', function () {
    add_filter('login_headerurl', '__return_empty_string'); // Removes the URL
    add_filter('login_headertext', '__return_empty_string'); // Removes the text
});

// Disable the <a> element around the logo
add_action('login_enqueue_scripts', function () {
    echo '<style>
        .wp-login-logo > a {
            pointer-events: none; /* Disables link functionality */
            cursor: default; /* Removes link appearance */
        }
    </style>';
});

add_action('login_init', function () {
    if (isset($_GET['action']) && $_GET['action'] === 'lostpassword') {
        wp_redirect(home_url()); // Redirects to the homepage
        exit;
    }
});


add_action('template_redirect', function () {
    if ( ! ( is_category() || is_tag() || is_search() || is_author() ) ) {
        return;
    }

    ob_start(function ($html) {
        if (class_exists('DOMDocument') && class_exists('DOMXPath')) {
            libxml_use_internal_errors(true);
            $dom = new DOMDocument('1.0', 'UTF-8');
            $loaded = $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
            if ($loaded) {
                $xpath = new DOMXPath($dom);
                $nodes = $xpath->query(
                    '//article//h1[
                        contains(concat(" ", normalize-space(@class), " "), " entry-title ")
                        or contains(concat(" ", normalize-space(@class), " "), " post-title ")
                        or contains(concat(" ", normalize-space(@class), " "), " card-title ")
                        or a[@rel="bookmark"]
                    ]'
                );

                if ($nodes && $nodes->length) {
                    foreach ($nodes as $h1) {
                        if (stripos($h1->getAttribute('class'), 'page-title') !== false) {
                            continue;
                        }
                        $h2 = $dom->createElement('h2');
                        if ($h1->hasAttributes()) {
                            foreach (iterator_to_array($h1->attributes) as $attr) {
                                $h2->setAttribute($attr->nodeName, $attr->nodeValue);
                            }
                        }
                        while ($h1->firstChild) {
                            $h2->appendChild($h1->firstChild);
                        }
                        $h1->parentNode->replaceChild($h2, $h1);
                    }
                    $newHtml = $dom->saveHTML();
                    if ($newHtml) {
                        $newHtml = preg_replace('/^<\?xml.+?\?>/i', '', $newHtml);
                        libxml_clear_errors();
                        return $newHtml;
                    }
                }
                libxml_clear_errors();
            }
        }

        $title_classes = '(entry-title|post-title|card-title)';

        $html = preg_replace(
            '#(<article\b[^>]*>.*?)<h1([^>]*\bclass=("|\")[^"\']*\b' . $title_classes . '\b[^"\']*\3[^>]*)>#is',
            '$1<h2$2>',
            $html
        );

        $html = preg_replace(
            '#(<article\b[^>]*>.*?<h2([^>]*)\bclass=("|\")[^"\']*\b' . $title_classes . '\b[^"\']*\3[^>]*>)(.*?)</h1>(.*?</article>)#is',
            '$1$4</h2>$5',
            $html
        );

        return $html;
    });
});
