<?php 
 header("HTTP/1.1 301 Moved Permanently"); 
 header("Location: https://freemap.in/"); 
 exit(); 
 ?> 

