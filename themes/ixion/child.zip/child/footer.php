<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ixion
 */

?>

	</div>
	<footer id="colophon" class="site-footer" role="contentinfo">
		<?php get_template_part( 'components/footer/widgets' ); ?>
		<?php get_template_part( 'components/footer/site', '' ); ?>
        <p class="info-footer">&copy; <?php echo date('Y'); ?> | All rights reserved by <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
	</footer>
</div>
<?php wp_footer(); ?>

</body>
</html>
