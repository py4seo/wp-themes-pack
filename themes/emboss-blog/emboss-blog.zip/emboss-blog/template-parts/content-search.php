<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Emboss Blog
 */

$button_label = get_theme_mod( 'emboss_blog_readmore_button_label', __( 'Read More', 'emboss-blog' ) );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( esc_attr( 'blog-post-single tile-design tile-style-1' ) ); ?>>
	<?php emboss_blog_post_thumbnail(); ?>
	<div class="mag-post-category">
		<?php emboss_blog_categories_list(); ?>
	</div>
	<?php
	if ( is_singular() ) :
		the_title( '<h1 class="entry-title mag-post-title">', '</h1>' );
	else :
		the_title( '<h2 class="entry-title mag-post-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
	endif;
	?>
	<div class="mag-post-meta">
		<?php
		emboss_blog_posted_by();
		emboss_blog_posted_on();
		?>
		<span class="post-views">
			<i class="far fa-eye"></i>
			<?php echo getPostViews( get_the_ID() ); ?>
		</span>
	</div>
	<div class="mag-post-excerpt">
		<?php the_excerpt(); ?>
	</div>
	<div class="ascen-btn-read">
		<div class="ascen-readmore-btn">
			<a href="<?php the_permalink(); ?>"><?php echo esc_html( $button_label ); ?></a>
		</div>
		<div class="ascen-min-read">
			<i class="far fa-clock"></i>
			<span>
				<?php
				echo emboss_blog_reading_time( get_the_content() );
				echo esc_html__( ' min read', 'emboss-blog' );
				?>
			</span>
		</div>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->
