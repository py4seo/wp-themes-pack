=== Emboss Blog ===

Contributors: ascendoor
Tags: custom-background, custom-logo, custom-colors, custom-menu, featured-images, threaded-comments, translation-ready, theme-options, footer-widgets, full-width-template, left-sidebar, right-sidebar, blog, portfolio, entertainment
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.4
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Emboss Blog is an ideal template created explicitly for bloggers and writers. Its elegant and responsive design makes it a fantastic selection for individual, life and style, well-being and wellness, culinary, beauty and vogue, travel, and diverse other categories of blogs. There is an extensive array of possibilities for personalization, allowing you to fashion your own magazine, newspaper, or blog using this template. Moreover, the theme offers numerous Google font alternatives, multiple layout choices, and the capacity to display or conceal segments. Additionally, arranging sections on the homepage based on your preferences is effortlessly achievable. Demo link: https://demos.ascendoor.com/emboss-blog/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Yes, the theme is integrated to work with following plugins:
* One Click Demo Import: This plugin is recommended to use for demo importing purpose.
* Contact Form 7: This plugin is recommended to use for contact forms on contact page.

== Changelog ==

= 1.0.0 =
* Initial release

== Images Screenshot ==

https://pxhere.com/en/photo/1355593
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/1458907
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/714532
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/1633009
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/484055
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/794150
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2018 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
* class-tgm-plugin-activation.php https://github.com/TGMPA/TGM-Plugin-Activation [GNU General Public License v2.0]
* Breadcrumb Trail: https://github.com/justintadlock/breadcrumb-trail, [GNU General Public License v2.0]
* Slick: https://github.com/kenwheeler/slick/, (c) 2017 Ken Wheeler, License: MIT license
* Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com, License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
* Google Fonts: https://fonts.google.com/, License: Apache License, version 2.0
* Webfonts Loader: https://github.com/WPTT/webfont-loader, License: MIT, https://github.com/WPTT/webfont-loader/blob/master/LICENSE
