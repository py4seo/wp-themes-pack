<?php
/**
 * Banner Section
 *
 * @package Emboss Blog
 */

$wp_customize->add_section(
	'emboss_blog_banner_section',
	array(
		'panel' => 'emboss_blog_front_page_options',
		'title' => esc_html__( 'Banner Section', 'emboss-blog' ),
	)
);

// Banner Section - Enable Section.
$wp_customize->add_setting(
	'emboss_blog_enable_banner_section',
	array(
		'default'           => false,
		'sanitize_callback' => 'emboss_blog_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Emboss_Blog_Toggle_Switch_Custom_Control(
		$wp_customize,
		'emboss_blog_enable_banner_section',
		array(
			'label'    => esc_html__( 'Enable Banner Section', 'emboss-blog' ),
			'section'  => 'emboss_blog_banner_section',
			'settings' => 'emboss_blog_enable_banner_section',
		)
	)
);

if ( isset( $wp_customize->selective_refresh ) ) {
	$wp_customize->selective_refresh->add_partial(
		'emboss_blog_enable_banner_section',
		array(
			'selector' => '#emboss_blog_banner_section .section-link',
			'settings' => 'emboss_blog_enable_banner_section',
		)
	);
}

// Banner Section - Banner Slider Content Type.
$wp_customize->add_setting(
	'emboss_blog_banner_slider_content_type',
	array(
		'default'           => 'post',
		'sanitize_callback' => 'emboss_blog_sanitize_select',
	)
);

$wp_customize->add_control(
	'emboss_blog_banner_slider_content_type',
	array(
		'label'           => esc_html__( 'Select Content Type', 'emboss-blog' ),
		'section'         => 'emboss_blog_banner_section',
		'settings'        => 'emboss_blog_banner_slider_content_type',
		'type'            => 'select',
		'active_callback' => 'emboss_blog_is_banner_section_enabled',
		'choices'         => array(
			'post'     => esc_html__( 'Post', 'emboss-blog' ),
			'category' => esc_html__( 'Category', 'emboss-blog' ),
		),
	)
);

for ( $i = 1; $i <= 3; $i++ ) {
	// Banner Section - Select Banner Post.
	$wp_customize->add_setting(
		'emboss_blog_banner_slider_content_post_' . $i,
		array(
			'sanitize_callback' => 'absint',
		)
	);

	$wp_customize->add_control(
		'emboss_blog_banner_slider_content_post_' . $i,
		array(
			'label'           => sprintf( esc_html__( 'Select Post %d', 'emboss-blog' ), $i ),
			'section'         => 'emboss_blog_banner_section',
			'settings'        => 'emboss_blog_banner_slider_content_post_' . $i,
			'active_callback' => 'emboss_blog_is_banner_slider_section_and_content_type_post_enabled',
			'type'            => 'select',
			'choices'         => emboss_blog_get_post_choices(),
		)
	);

}

// Banner Section - Select Banner Category.
$wp_customize->add_setting(
	'emboss_blog_banner_slider_content_category',
	array(
		'sanitize_callback' => 'emboss_blog_sanitize_select',
	)
);

$wp_customize->add_control(
	'emboss_blog_banner_slider_content_category',
	array(
		'label'           => esc_html__( 'Select Category', 'emboss-blog' ),
		'section'         => 'emboss_blog_banner_section',
		'settings'        => 'emboss_blog_banner_slider_content_category',
		'active_callback' => 'emboss_blog_is_banner_section_and_content_type_category_enabled',
		'type'            => 'select',
		'choices'         => emboss_blog_get_post_cat_choices(),
	)
);

// Banner Section - Horizontal Line.
$wp_customize->add_setting(
	'emboss_blog_banner_horizontal_line',
	array(
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new Emboss_Blog_Customize_Horizontal_Line(
		$wp_customize,
		'emboss_blog_banner_horizontal_line',
		array(
			'section'         => 'emboss_blog_banner_section',
			'settings'        => 'emboss_blog_banner_horizontal_line',
			'active_callback' => 'emboss_blog_is_banner_section_enabled',
			'type'            => 'hr',
		)
	)
);

// Banner Section - Recent Title.
$wp_customize->add_setting(
	'emboss_blog_banner_section_recent_title',
	array(
		'default'           => __( 'Recent', 'emboss-blog' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'emboss_blog_banner_section_recent_title',
	array(
		'label'           => esc_html__( 'Recent Title Label', 'emboss-blog' ),
		'section'         => 'emboss_blog_banner_section',
		'settings'        => 'emboss_blog_banner_section_recent_title',
		'type'            => 'text',
		'active_callback' => 'emboss_blog_is_banner_section_enabled',
	)
);

// Banner Section - Popular Title.
$wp_customize->add_setting(
	'emboss_blog_banner_section_popular_title',
	array(
		'default'           => __( 'Popular', 'emboss-blog' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'emboss_blog_banner_section_popular_title',
	array(
		'label'           => esc_html__( 'Popular Title Label', 'emboss-blog' ),
		'section'         => 'emboss_blog_banner_section',
		'settings'        => 'emboss_blog_banner_section_popular_title',
		'type'            => 'text',
		'active_callback' => 'emboss_blog_is_banner_section_enabled',
	)
);
