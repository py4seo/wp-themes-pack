<?php
/**
 * Front Page Options
 *
 * @package Emboss Blog
 */

$wp_customize->add_panel(
	'emboss_blog_front_page_options',
	array(
		'title'    => esc_html__( 'Front Page Options', 'emboss-blog' ),
		'priority' => 130,
	)
);

// Banner Section.
require get_template_directory() . '/inc/customizer/front-page-options/banner.php';
