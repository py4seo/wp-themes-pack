<?php

/**
 * Active Callbacks
 *
 * @package Emboss Blog
 */

// Theme Options.
function emboss_blog_is_pagination_enabled( $control ) {
	return ( $control->manager->get_setting( 'emboss_blog_enable_pagination' )->value() );
}
function emboss_blog_is_breadcrumb_enabled( $control ) {
	return ( $control->manager->get_setting( 'emboss_blog_enable_breadcrumb' )->value() );
}

// Check if static home page is enabled.
function emboss_blog_is_static_homepage_enabled( $control ) {
	return ( 'page' === $control->manager->get_setting( 'show_on_front' )->value() );
}

// Banner Slider Section.
function emboss_blog_is_banner_section_enabled( $control ) {
	return ( $control->manager->get_setting( 'emboss_blog_enable_banner_section' )->value() );
}
function emboss_blog_is_banner_slider_section_and_content_type_post_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'emboss_blog_banner_slider_content_type' )->value();
	return ( emboss_blog_is_banner_section_enabled( $control ) && ( 'post' === $content_type ) );
}
function emboss_blog_is_banner_section_and_content_type_category_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'emboss_blog_banner_slider_content_type' )->value();
	return ( emboss_blog_is_banner_section_enabled( $control ) && ( 'category' === $content_type ) );
}
