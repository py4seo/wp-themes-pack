<?php
/**
 * Post Options
 *
 * @package Emboss Blog
 */

$wp_customize->add_section(
	'emboss_blog_post_options',
	array(
		'title' => esc_html__( 'Post Options', 'emboss-blog' ),
		'panel' => 'emboss_blog_theme_options',
	)
);

// Post Options - Hide Date.
$wp_customize->add_setting(
	'emboss_blog_post_hide_date',
	array(
		'default'           => false,
		'sanitize_callback' => 'emboss_blog_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Emboss_Blog_Toggle_Switch_Custom_Control(
		$wp_customize,
		'emboss_blog_post_hide_date',
		array(
			'label'   => esc_html__( 'Hide Date', 'emboss-blog' ),
			'section' => 'emboss_blog_post_options',
		)
	)
);

// Post Options - Hide Author.
$wp_customize->add_setting(
	'emboss_blog_post_hide_author',
	array(
		'default'           => false,
		'sanitize_callback' => 'emboss_blog_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Emboss_Blog_Toggle_Switch_Custom_Control(
		$wp_customize,
		'emboss_blog_post_hide_author',
		array(
			'label'   => esc_html__( 'Hide Author', 'emboss-blog' ),
			'section' => 'emboss_blog_post_options',
		)
	)
);

// Post Options - Hide Category.
$wp_customize->add_setting(
	'emboss_blog_post_hide_category',
	array(
		'default'           => false,
		'sanitize_callback' => 'emboss_blog_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Emboss_Blog_Toggle_Switch_Custom_Control(
		$wp_customize,
		'emboss_blog_post_hide_category',
		array(
			'label'   => esc_html__( 'Hide Category', 'emboss-blog' ),
			'section' => 'emboss_blog_post_options',
		)
	)
);

// Post Options - Hide Tag.
$wp_customize->add_setting(
	'emboss_blog_post_hide_tags',
	array(
		'default'           => false,
		'sanitize_callback' => 'emboss_blog_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Emboss_Blog_Toggle_Switch_Custom_Control(
		$wp_customize,
		'emboss_blog_post_hide_tags',
		array(
			'label'   => esc_html__( 'Hide Tag', 'emboss-blog' ),
			'section' => 'emboss_blog_post_options',
		)
	)
);

// Post Options - Related Post Label.
$wp_customize->add_setting(
	'emboss_blog_post_related_post_label',
	array(
		'default'           => __( 'Related Posts', 'emboss-blog' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'emboss_blog_post_related_post_label',
	array(
		'label'    => esc_html__( 'Related Posts Label', 'emboss-blog' ),
		'section'  => 'emboss_blog_post_options',
		'settings' => 'emboss_blog_post_related_post_label',
		'type'     => 'text',
	)
);


