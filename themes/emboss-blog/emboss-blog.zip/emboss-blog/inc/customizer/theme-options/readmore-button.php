<?php
/**
 * Read More Button
 *
 * @package Emboss Blog
 */

$wp_customize->add_section(
	'emboss_blog_readmore_button_setting',
	array(
		'title' => esc_html__( 'Read More Button', 'emboss-blog' ),
		'panel' => 'emboss_blog_theme_options',
	)
);

// Read More Button - Button label.
$wp_customize->add_setting(
	'emboss_blog_readmore_button_label',
	array(
		'default'           => __( 'Read More', 'emboss-blog' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'emboss_blog_readmore_button_label',
	array(
		'label'    => esc_html__( 'Read More Button label', 'emboss-blog' ),
		'section'  => 'emboss_blog_readmore_button_setting',
		'settings' => 'emboss_blog_readmore_button_label',
		'type'     => 'text',
	)
);
