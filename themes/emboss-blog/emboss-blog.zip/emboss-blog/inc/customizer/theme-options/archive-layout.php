<?php
/**
 * Archive Layout
 *
 * @package Emboss Blog
 */

$wp_customize->add_section(
	'emboss_blog_archive_layout',
	array(
		'title' => esc_html__( 'Archive Layout', 'emboss-blog' ),
		'panel' => 'emboss_blog_theme_options',
	)
);

// Archive Layout - Column Layout.
$wp_customize->add_setting(
	'emboss_blog_archive_column_layout',
	array(
		'default'           => 'column-2',
		'sanitize_callback' => 'emboss_blog_sanitize_select',
	)
);

$wp_customize->add_control(
	'emboss_blog_archive_column_layout',
	array(
		'label'   => esc_html__( 'Select Column Layout', 'emboss-blog' ),
		'section' => 'emboss_blog_archive_layout',
		'type'    => 'select',
		'choices' => array(
			'column-2' => __( 'Column 2', 'emboss-blog' ),
			'column-3' => __( 'Column 3', 'emboss-blog' ),
		),
	)
);
