<?php
/**
 * Typography
 *
 * @package Emboss Blog
 */

$wp_customize->add_section(
	'emboss_blog_typography',
	array(
		'panel' => 'emboss_blog_theme_options',
		'title' => esc_html__( 'Typography', 'emboss-blog' ),
	)
);

// Typography - Site Title Font.
$wp_customize->add_setting(
	'emboss_blog_site_title_font',
	array(
		'default'           => 'Sora',
		'sanitize_callback' => 'emboss_blog_sanitize_google_fonts',
	)
);

$wp_customize->add_control(
	'emboss_blog_site_title_font',
	array(
		'label'    => esc_html__( 'Site Title Font Family', 'emboss-blog' ),
		'section'  => 'emboss_blog_typography',
		'settings' => 'emboss_blog_site_title_font',
		'type'     => 'select',
		'choices'  => emboss_blog_get_all_google_font_families(),
	)
);

// Typography - Site Description Font.
$wp_customize->add_setting(
	'emboss_blog_site_description_font',
	array(
		'default'           => 'Comfortaa',
		'sanitize_callback' => 'emboss_blog_sanitize_google_fonts',
	)
);

$wp_customize->add_control(
	'emboss_blog_site_description_font',
	array(
		'label'    => esc_html__( 'Site Description Font Family', 'emboss-blog' ),
		'section'  => 'emboss_blog_typography',
		'settings' => 'emboss_blog_site_description_font',
		'type'     => 'select',
		'choices'  => emboss_blog_get_all_google_font_families(),
	)
);

// Typography - Header Font.
$wp_customize->add_setting(
	'emboss_blog_header_font',
	array(
		'default'           => 'Inter',
		'sanitize_callback' => 'emboss_blog_sanitize_google_fonts',
	)
);

$wp_customize->add_control(
	'emboss_blog_header_font',
	array(
		'label'    => esc_html__( 'Header Font Family', 'emboss-blog' ),
		'section'  => 'emboss_blog_typography',
		'settings' => 'emboss_blog_header_font',
		'type'     => 'select',
		'choices'  => emboss_blog_get_all_google_font_families(),
	)
);

// Typography - Body Font.
$wp_customize->add_setting(
	'emboss_blog_body_font',
	array(
		'default'           => 'Inter',
		'sanitize_callback' => 'emboss_blog_sanitize_google_fonts',
	)
);

$wp_customize->add_control(
	'emboss_blog_body_font',
	array(
		'label'    => esc_html__( 'Body Font Family', 'emboss-blog' ),
		'section'  => 'emboss_blog_typography',
		'settings' => 'emboss_blog_body_font',
		'type'     => 'select',
		'choices'  => emboss_blog_get_all_google_font_families(),
	)
);
