<?php
/**
 * Excerpt
 *
 * @package Emboss Blog
 */

$wp_customize->add_section(
	'emboss_blog_excerpt_options',
	array(
		'panel' => 'emboss_blog_theme_options',
		'title' => esc_html__( 'Excerpt', 'emboss-blog' ),
	)
);

// Excerpt - Excerpt Length.
$wp_customize->add_setting(
	'emboss_blog_excerpt_length',
	array(
		'default'           => 20,
		'sanitize_callback' => 'emboss_blog_sanitize_number_range',
		'validate_callback' => 'emboss_blog_validate_excerpt_length',
	)
);

$wp_customize->add_control(
	'emboss_blog_excerpt_length',
	array(
		'label'       => esc_html__( 'Excerpt Length (no. of words)', 'emboss-blog' ),
		'description' => esc_html__( 'Note: Min 1 & Max 100. Please input the valid number and save. Then refresh the page to see the change.', 'emboss-blog' ),
		'section'     => 'emboss_blog_excerpt_options',
		'settings'    => 'emboss_blog_excerpt_length',
		'type'        => 'number',
		'input_attrs' => array(
			'min'  => 1,
			'max'  => 100,
			'step' => 1,
		),
	)
);
