<?php
/**
 * Pagination
 *
 * @package Emboss Blog
 */

$wp_customize->add_section(
	'emboss_blog_pagination',
	array(
		'panel' => 'emboss_blog_theme_options',
		'title' => esc_html__( 'Pagination', 'emboss-blog' ),
	)
);

// Pagination - Enable Pagination.
$wp_customize->add_setting(
	'emboss_blog_enable_pagination',
	array(
		'default'           => true,
		'sanitize_callback' => 'emboss_blog_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Emboss_Blog_Toggle_Switch_Custom_Control(
		$wp_customize,
		'emboss_blog_enable_pagination',
		array(
			'label'    => esc_html__( 'Enable Pagination', 'emboss-blog' ),
			'section'  => 'emboss_blog_pagination',
			'settings' => 'emboss_blog_enable_pagination',
			'type'     => 'checkbox',
		)
	)
);

// Pagination - Pagination Type.
$wp_customize->add_setting(
	'emboss_blog_pagination_type',
	array(
		'default'           => 'numeric',
		'sanitize_callback' => 'emboss_blog_sanitize_select',
	)
);

$wp_customize->add_control(
	'emboss_blog_pagination_type',
	array(
		'label'           => esc_html__( 'Pagination Type', 'emboss-blog' ),
		'section'         => 'emboss_blog_pagination',
		'settings'        => 'emboss_blog_pagination_type',
		'active_callback' => 'emboss_blog_is_pagination_enabled',
		'type'            => 'select',
		'choices'         => array(
			'default' => __( 'Default (Older/Newer)', 'emboss-blog' ),
			'numeric' => __( 'Numeric', 'emboss-blog' ),
		),
	)
);
