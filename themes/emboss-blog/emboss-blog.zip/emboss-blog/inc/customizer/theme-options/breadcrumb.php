<?php
/**
 * Breadcrumb
 *
 * @package Emboss Blog
 */

$wp_customize->add_section(
	'emboss_blog_breadcrumb',
	array(
		'title' => esc_html__( 'Breadcrumb', 'emboss-blog' ),
		'panel' => 'emboss_blog_theme_options',
	)
);

// Breadcrumb - Enable Breadcrumb.
$wp_customize->add_setting(
	'emboss_blog_enable_breadcrumb',
	array(
		'sanitize_callback' => 'emboss_blog_sanitize_switch',
		'default'           => true,
	)
);

$wp_customize->add_control(
	new Emboss_Blog_Toggle_Switch_Custom_Control(
		$wp_customize,
		'emboss_blog_enable_breadcrumb',
		array(
			'label'   => esc_html__( 'Enable Breadcrumb', 'emboss-blog' ),
			'section' => 'emboss_blog_breadcrumb',
		)
	)
);

// Breadcrumb - Separator.
$wp_customize->add_setting(
	'emboss_blog_breadcrumb_separator',
	array(
		'sanitize_callback' => 'sanitize_text_field',
		'default'           => '/',
	)
);

$wp_customize->add_control(
	'emboss_blog_breadcrumb_separator',
	array(
		'label'           => esc_html__( 'Separator', 'emboss-blog' ),
		'active_callback' => 'emboss_blog_is_breadcrumb_enabled',
		'section'         => 'emboss_blog_breadcrumb',
	)
);
