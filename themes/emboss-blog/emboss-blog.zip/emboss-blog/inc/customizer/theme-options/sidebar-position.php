<?php
/**
 * Sidebar Position
 *
 * @package Emboss Blog
 */

$wp_customize->add_section(
	'emboss_blog_sidebar_position',
	array(
		'title' => esc_html__( 'Sidebar Position', 'emboss-blog' ),
		'panel' => 'emboss_blog_theme_options',
	)
);

// Sidebar Position - Global Sidebar Position.
$wp_customize->add_setting(
	'emboss_blog_sidebar_position',
	array(
		'sanitize_callback' => 'emboss_blog_sanitize_select',
		'default'           => 'right-sidebar',
	)
);

$wp_customize->add_control(
	'emboss_blog_sidebar_position',
	array(
		'label'   => esc_html__( 'Global Sidebar Position', 'emboss-blog' ),
		'section' => 'emboss_blog_sidebar_position',
		'type'    => 'select',
		'choices' => array(
			'right-sidebar' => esc_html__( 'Right Sidebar', 'emboss-blog' ),
			'no-sidebar'    => esc_html__( 'No Sidebar', 'emboss-blog' ),
		),
	)
);

// Sidebar Position - Post Sidebar Position.
$wp_customize->add_setting(
	'emboss_blog_post_sidebar_position',
	array(
		'sanitize_callback' => 'emboss_blog_sanitize_select',
		'default'           => 'right-sidebar',
	)
);

$wp_customize->add_control(
	'emboss_blog_post_sidebar_position',
	array(
		'label'   => esc_html__( 'Post Sidebar Position', 'emboss-blog' ),
		'section' => 'emboss_blog_sidebar_position',
		'type'    => 'select',
		'choices' => array(
			'right-sidebar' => esc_html__( 'Right Sidebar', 'emboss-blog' ),
			'no-sidebar'    => esc_html__( 'No Sidebar', 'emboss-blog' ),
		),
	)
);

// Sidebar Position - Page Sidebar Position.
$wp_customize->add_setting(
	'emboss_blog_page_sidebar_position',
	array(
		'sanitize_callback' => 'emboss_blog_sanitize_select',
		'default'           => 'right-sidebar',
	)
);

$wp_customize->add_control(
	'emboss_blog_page_sidebar_position',
	array(
		'label'   => esc_html__( 'Page Sidebar Position', 'emboss-blog' ),
		'section' => 'emboss_blog_sidebar_position',
		'type'    => 'select',
		'choices' => array(
			'right-sidebar' => esc_html__( 'Right Sidebar', 'emboss-blog' ),
			'no-sidebar'    => esc_html__( 'No Sidebar', 'emboss-blog' ),
		),
	)
);
