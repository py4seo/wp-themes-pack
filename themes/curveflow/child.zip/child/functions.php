<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );



function custom_excerpt_length($content) {
    global $post;
    $content = get_the_content();
    $trimmed_content = mb_substr($content, 0, 550) . '...';
    return $trimmed_content;
}

add_filter('the_excerpt', 'custom_excerpt_length', 10);
add_filter('get_the_excerpt', 'custom_excerpt_length', 10);
add_filter('wp_trim_excerpt', 'custom_excerpt_length', 10);



function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');


/*  Site name/logo (logo outside H1, single wrapper)
/* ------------------------------------ */
if ( ! function_exists( 'curveflow_site_title' ) ) {

	function curveflow_site_title() {

		$site_name      = get_bloginfo( 'name' );
		$custom_logo_id = get_theme_mod( 'custom_logo' );
		$logo_src       = $custom_logo_id ? wp_get_attachment_image_src( $custom_logo_id, 'full' ) : false;

		$tag = ( is_front_page() || is_home() ) ? 'h1' : 'p';

		// ЕДИНЫЙ КОНТЕЙНЕР — занимает то же место, что раньше занимал H1/P
		$out  = '<div class="site-title-wrap">' . "\n";

		// ЛОГОТИП отдельно (если есть)
		if ( function_exists( 'has_custom_logo' ) && has_custom_logo() && ! empty( $logo_src[0] ) ) {
			$out .= '  <a class="site-logo" href="' . esc_url( home_url( '/' ) ) . '" rel="home">'
			      . '    <img src="' . esc_url( $logo_src[0] ) . '" alt="' . esc_attr( $site_name ) . '">'
			      . '  </a>' . "\n";
		}

		// ТЕКСТОВЫЙ ТАЙТЛ — только он в H1 на главной
		if ( $site_name ) {
			$out .= '  <' . $tag . ' class="site-title">'
			      . '    <a href="' . esc_url( home_url( '/' ) ) . '" rel="home">' . esc_html( $site_name ) . '</a>'
			      . '  </' . $tag . '>' . "\n";
		}

		$out .= '</div>' . "\n";

		return $out;
	}
}


