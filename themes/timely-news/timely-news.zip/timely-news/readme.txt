=== Timely News ===

Contributors: artifythemes
Tags: custom-background, custom-header, custom-logo, custom-menu, featured-images, left-sidebar, right-sidebar, blog, one-column, portfolio, photography, theme-options, threaded-comments, translation-ready
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Timely News is a modern, versatile WordPress theme designed for professional bloggers. Lightweight yet highly customizable, it’s an ideal choice for niches such as fashion, lifestyle, travel, food, and photography. The theme is fully responsive, mobile-friendly, and optimized for speed and accessibility. With cross-browser support and translation-ready functionality, it delivers a smooth, consistent experience for bloggers and readers across all devices and languages. Live preview : https://demo.artifythemes.com/timely-news/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

The theme is integrated to work with following plugins:
* One Click Demo Import: This plugin is recommended to use for demo importing purpose.
* Contact Form 7: This plugin is recommended to use for contact forms on contact page.

== How does the demo importer works? ==
Just install the recommended plugin i.e. One Click Demo Import when the theme is activated and then go to Appearance->Import demo data. From there, select the demo files to be uploaded which is included with the theme itself in [demo] folder.

== Changelog ==

= 1.0.0 - September 15 2025 =
* Initial release

== Copyright ==

Timely News WordPress Theme, Copyright 2025 Artify Themes

Timely News bundles the following third-party resources:

Slick 1.8.1 Copyright (c) Ken Wheeler
License: MIT license.
Source: https://github.com/kenwheeler/slick/

Font Awesome Free 6.7.2 by @fontawesome
Licenses: MIT License
Source: https://fontawesome.com/license/free

Magnific Popup - v1.2.0 Copyright (c) 2024 Dmytro Semenov
Licenses: MIT License
Source: https://github.com/dimsemenov/Magnific-Popup

jQuery Conveyor Ticker (jConveyorTicker)
Licenses: MIT License
Source: https://github.com/lluz/jquery-conveyor-ticker

Webfonts Loader Copyright (c) 2020 WPTT
Licenses: MIT License
Source: https://github.com/WPTT/webfont-loader

Based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later]
Source: https://www.gnu.org/licenses/gpl-2.0.html

normalize.css, (C) 2012-2018 Nicolas Gallagher and Jonathan Neal, 
Licenses: [MIT License](https://opensource.org/licenses/MIT)
Source: https://necolas.github.io/normalize.css/

class-breadcrumb-trail.php , (C) 2008-2017 Justin Tadlock, [ GNU GPL, version 2 or later]
Source: https://github.com/justintadlock/breadcrumb-trail

class-tgm-plugin-activation.php , [GNU General Public License v2.0]
Source: https://github.com/TGMPA/TGM-Plugin-Activation

Customizer Pro, 2016 © Justin Tadlock. [GNU General Public License v2.0]
Source: https://github.com/justintadlock/trt-customizer-pro

== Images Copyright ==

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1626590

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1119489

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1620892

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/885282

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1626590

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1125497

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1119489

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1620892

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1229568

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/593359

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/780582

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/739321

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1125497

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/35530

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/846217

License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1172567
