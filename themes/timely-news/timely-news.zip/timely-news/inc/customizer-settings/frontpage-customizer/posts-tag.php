<?php
/**
 * Posts Tag Section
 *
 * @package Timely News
 */

$wp_customize->add_section(
	'timely_news_posts_tag_section',
	array(
        'title' => esc_html__( 'Posts Tag Section', 'timely-news' ),
		'panel' => 'timely_news_frontpage_panel',
	)
);

// Posts Tag Section - Enable Section.
$wp_customize->add_setting(
	'timely_news_enable_posts_tag_section',
	array(
		'default'           => false,
		'sanitize_callback' => 'timely_news_sanitize_checkbox',
	)
);

$wp_customize->add_control(
	new Timely_News_Toggle_Checkbox_Custom_control(
		$wp_customize,
		'timely_news_enable_posts_tag_section',
		array(
			'label'    => esc_html__( 'Enable Posts Tag Section', 'timely-news' ),
			'section'  => 'timely_news_posts_tag_section',
			'settings' => 'timely_news_enable_posts_tag_section',
		)
	)
);

if ( isset( $wp_customize->selective_refresh ) ) {
	$wp_customize->selective_refresh->add_partial(
		'timely_news_enable_posts_tag_section',
		array(
			'selector' => '#timely_news_posts_tag_section .section-link',
			'settings' => 'timely_news_enable_posts_tag_section',
		)
	);
}

// Posts Tag Section - Section Title.
$wp_customize->add_setting(
	'timely_news_posts_tag_title',
	array(
		'default'           => __( 'Posts Tag:', 'timely-news' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'timely_news_posts_tag_title',
	array(
		'label'           => esc_html__( 'Section Title', 'timely-news' ),
		'section'         => 'timely_news_posts_tag_section',
		'settings'        => 'timely_news_posts_tag_title',
		'type'            => 'text',
		'active_callback' => 'timely_news_is_posts_tag_enabled',
	)
);

/*========================Active Callback==============================*/
function timely_news_is_posts_tag_enabled( $control ) {
	return $control->manager->get_setting( 'timely_news_enable_posts_tag_section' )->value();
}