<?php
/**
 * Frontpage Customizer Settings
 *
 * @package Timely News
 *
 * Banner Section
 */

$wp_customize->add_section(
	'timely_news_banner_section',
	array(
		'title' => esc_html__( 'Banner Section', 'timely-news' ),
		'panel' => 'timely_news_frontpage_panel',
	)
);

// Banner section enable settings.
$wp_customize->add_setting(
	'timely_news_banner_section_enable',
	array(
		'default'           => false,
		'sanitize_callback' => 'timely_news_sanitize_checkbox',
	)
);
$wp_customize->add_control(
	new Timely_News_Toggle_Checkbox_Custom_control(
		$wp_customize,
		'timely_news_banner_section_enable',
		array(
			'label'    => esc_html__( 'Enable Banner Section', 'timely-news' ),
			'type'     => 'checkbox',
			'settings' => 'timely_news_banner_section_enable',
			'section'  => 'timely_news_banner_section',
		)
	)
);

// Banner Posts Sub Heading.
$wp_customize->add_setting(
	'timely_news_banner_posts_sub_heading',
	array(
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new Timely_News_Section_Sub_Heading_Control(
		$wp_customize,
		'timely_news_banner_posts_sub_heading',
		array(
			'label'           => esc_html__( 'Banner Posts Section', 'timely-news' ),
			'settings'        => 'timely_news_banner_posts_sub_heading',
			'section'         => 'timely_news_banner_section',
			'active_callback' => 'timely_news_if_banner_enabled',
		)
	)
);


// banner content type settings.
$wp_customize->add_setting(
	'timely_news_banner_posts_content_type',
	array(
		'default'           => 'post',
		'sanitize_callback' => 'timely_news_sanitize_select',
	)
);

$wp_customize->add_control(
	'timely_news_banner_posts_content_type',
	array(
		'label'           => esc_html__( 'Content type:', 'timely-news' ),
		'description'     => esc_html__( 'Choose where you want to render the content from.', 'timely-news' ),
		'section'         => 'timely_news_banner_section',
		'type'            => 'select',
		'active_callback' => 'timely_news_if_banner_enabled',
		'choices'         => array(
			'post'     => esc_html__( 'Post', 'timely-news' ),
			'category' => esc_html__( 'Category', 'timely-news' ),
		),
	)
);

for ( $i = 1; $i <= 3; $i++ ) {
	// banner post setting.
	$wp_customize->add_setting(
		'timely_news_banner_posts_post_' . $i,
		array(
			'sanitize_callback' => 'timely_news_sanitize_dropdown_pages',
		)
	);

	$wp_customize->add_control(
		'timely_news_banner_posts_post_' . $i,
		array(
			'label'           => sprintf( esc_html__( 'Post %d', 'timely-news' ), $i ),
			'section'         => 'timely_news_banner_section',
			'type'            => 'select',
			'choices'         => timely_news_get_post_choices(),
			'active_callback' => 'timely_news_banner_posts_content_type_post_enabled',
		)
	);

}

// banner category setting.
$wp_customize->add_setting(
	'timely_news_banner_posts_category',
	array(
		'sanitize_callback' => 'timely_news_sanitize_select',
	)
);

$wp_customize->add_control(
	'timely_news_banner_posts_category',
	array(
		'label'           => esc_html__( 'Category', 'timely-news' ),
		'section'         => 'timely_news_banner_section',
		'type'            => 'select',
		'choices'         => timely_news_get_post_cat_choices(),
		'active_callback' => 'timely_news_banner_posts_content_type_category_enabled',
	)
);

// Banner Top Stories Sub Heading.
$wp_customize->add_setting(
	'timely_news_banner_top_stories_sub_heading',
	array(
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new Timely_News_Section_Sub_Heading_Control(
		$wp_customize,
		'timely_news_banner_top_stories_sub_heading',
		array(
			'label'           => esc_html__( 'Banner Top Stories Section', 'timely-news' ),
			'settings'        => 'timely_news_banner_top_stories_sub_heading',
			'section'         => 'timely_news_banner_section',
			'active_callback' => 'timely_news_if_banner_enabled',
		)
	)
);

// Top Stories title settings.
$wp_customize->add_setting(
	'timely_news_banner_top_stories_title',
	array(
		'default'           => __( 'Top Stories', 'timely-news' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'timely_news_banner_top_stories_title',
	array(
		'label'           => esc_html__( 'Section Title', 'timely-news' ),
		'section'         => 'timely_news_banner_section',
		'active_callback' => 'timely_news_if_banner_enabled',
	)
);

// Abort if selective refresh is not available.
if ( isset( $wp_customize->selective_refresh ) ) {
	$wp_customize->selective_refresh->add_partial(
		'timely_news_banner_top_stories_title',
		array(
			'selector'            => '.banner-section .top-stories h3.section-title',
			'settings'            => 'timely_news_banner_top_stories_title',
			'container_inclusive' => false,
			'fallback_refresh'    => true,
		)
	);
}

// banner content type settings.
$wp_customize->add_setting(
	'timely_news_banner_top_stories_content_type',
	array(
		'default'           => 'post',
		'sanitize_callback' => 'timely_news_sanitize_select',
	)
);

$wp_customize->add_control(
	'timely_news_banner_top_stories_content_type',
	array(
		'label'           => esc_html__( 'Content type:', 'timely-news' ),
		'description'     => esc_html__( 'Choose where you want to render the content from.', 'timely-news' ),
		'section'         => 'timely_news_banner_section',
		'type'            => 'select',
		'active_callback' => 'timely_news_if_banner_enabled',
		'choices'         => array(
			'post'     => esc_html__( 'Post', 'timely-news' ),
			'category' => esc_html__( 'Category', 'timely-news' ),
		),
	)
);

for ( $i = 1; $i <= 6; $i++ ) {
	// banner post setting.
	$wp_customize->add_setting(
		'timely_news_banner_top_stories_post_' . $i,
		array(
			'sanitize_callback' => 'timely_news_sanitize_dropdown_pages',
		)
	);

	$wp_customize->add_control(
		'timely_news_banner_top_stories_post_' . $i,
		array(
			'label'           => sprintf( esc_html__( 'Post %d', 'timely-news' ), $i ),
			'section'         => 'timely_news_banner_section',
			'type'            => 'select',
			'choices'         => timely_news_get_post_choices(),
			'active_callback' => 'timely_news_banner_top_stories_content_type_post_enabled',
		)
	);

}

// banner category setting.
$wp_customize->add_setting(
	'timely_news_banner_top_stories_category',
	array(
		'sanitize_callback' => 'timely_news_sanitize_select',
	)
);

$wp_customize->add_control(
	'timely_news_banner_top_stories_category',
	array(
		'label'           => esc_html__( 'Category', 'timely-news' ),
		'section'         => 'timely_news_banner_section',
		'type'            => 'select',
		'choices'         => timely_news_get_post_cat_choices(),
		'active_callback' => 'timely_news_banner_top_stories_content_type_category_enabled',
	)
);

/*========================Active Callback==============================*/
function timely_news_if_banner_enabled( $control ) {
	return $control->manager->get_setting( 'timely_news_banner_section_enable' )->value();
}
//Banner Posts.
function timely_news_banner_posts_content_type_post_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'timely_news_banner_posts_content_type' )->value();
	return timely_news_if_banner_enabled( $control ) && ( 'post' === $content_type );
}
function timely_news_banner_posts_content_type_category_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'timely_news_banner_posts_content_type' )->value();
	return timely_news_if_banner_enabled( $control ) && ( 'category' === $content_type );
}
//Banner Top Stories.
function timely_news_banner_top_stories_content_type_post_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'timely_news_banner_top_stories_content_type' )->value();
	return timely_news_if_banner_enabled( $control ) && ( 'post' === $content_type );
}
function timely_news_banner_top_stories_content_type_category_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'timely_news_banner_top_stories_content_type' )->value();
	return timely_news_if_banner_enabled( $control ) && ( 'category' === $content_type );
}
