<?php

/**
 * Color Options
 */

// Site tagline color setting.
$wp_customize->add_setting(
	'timely_news_header_tagline',
	array(
		'default'           => '#141414',
		'sanitize_callback' => 'timely_news_sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'timely_news_header_tagline',
		array(
			'label'   => esc_html__( 'Site tagline Color', 'timely-news' ),
			'section' => 'colors',
		)
	)
);
