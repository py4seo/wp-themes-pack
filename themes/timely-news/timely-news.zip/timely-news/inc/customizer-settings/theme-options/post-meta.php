<?php

$wp_customize->add_section(
	'timely_news_posts_meta_options',
	array(
		'title' => esc_html__( 'Post Meta Options', 'timely-news' ),
		'panel' => 'timely_news_theme_options_panel',
	)
);

// Enable post category setting.
$wp_customize->add_setting(
	'timely_news_enable_category',
	array(
		'default'           => true,
		'sanitize_callback' => 'timely_news_sanitize_checkbox',
	)
);

$wp_customize->add_control(
	new Timely_News_Toggle_Checkbox_Custom_control(
		$wp_customize,
		'timely_news_enable_category',
		array(
			'label'    => esc_html__( 'Enable Category', 'timely-news' ),
			'settings' => 'timely_news_enable_category',
			'section'  => 'timely_news_posts_meta_options',
			'type'     => 'checkbox',
		)
	)
);

// Enable post author setting.
$wp_customize->add_setting(
	'timely_news_enable_author',
	array(
		'default'           => true,
		'sanitize_callback' => 'timely_news_sanitize_checkbox',
	)
);

$wp_customize->add_control(
	new Timely_News_Toggle_Checkbox_Custom_control(
		$wp_customize,
		'timely_news_enable_author',
		array(
			'label'    => esc_html__( 'Enable Author', 'timely-news' ),
			'settings' => 'timely_news_enable_author',
			'section'  => 'timely_news_posts_meta_options',
			'type'     => 'checkbox',
		)
	)
);

// Enable post date setting.
$wp_customize->add_setting(
	'timely_news_enable_date',
	array(
		'default'           => true,
		'sanitize_callback' => 'timely_news_sanitize_checkbox',
	)
);

$wp_customize->add_control(
	new Timely_News_Toggle_Checkbox_Custom_control(
		$wp_customize,
		'timely_news_enable_date',
		array(
			'label'    => esc_html__( 'Enable Date', 'timely-news' ),
			'settings' => 'timely_news_enable_date',
			'section'  => 'timely_news_posts_meta_options',
			'type'     => 'checkbox',
		)
	)
);

// Enable post tag setting.
$wp_customize->add_setting(
	'timely_news_enable_tag',
	array(
		'default'           => true,
		'sanitize_callback' => 'timely_news_sanitize_checkbox',
	)
);

$wp_customize->add_control(
	new Timely_News_Toggle_Checkbox_Custom_control(
		$wp_customize,
		'timely_news_enable_tag',
		array(
			'label'    => esc_html__( 'Enable Post Tag', 'timely-news' ),
			'settings' => 'timely_news_enable_tag',
			'section'  => 'timely_news_posts_meta_options',
			'type'     => 'checkbox',
		)
	)
);