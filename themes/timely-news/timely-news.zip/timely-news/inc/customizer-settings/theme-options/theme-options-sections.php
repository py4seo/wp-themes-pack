<?php

/**
 * Theme Options.
 */

$wp_customize->add_panel(
	'timely_news_theme_options_panel',
	array(
		'title'    => esc_html__( 'Theme Options', 'timely-news' ),
		'priority' => 150,
	)
);

$theme_options = array( 'font-options', 'breadcrumb', 'post-meta', 'archive-options', 'single-post', 'sidebar-layout', 'pagination', 'footer' );

foreach ( $theme_options as $customizer ) {
	require get_template_directory() . '/inc/customizer-settings/theme-options/' . $customizer . '.php';

}
