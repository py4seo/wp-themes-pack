<?php
/**
 * Sidebar settings
 */

$wp_customize->add_section(
	'timely_news_sidebar_option',
	array(
		'title' => esc_html__( 'Sidebar Options', 'timely-news' ),
		'panel' => 'timely_news_theme_options_panel',
	)
);

// Sidebar Option - Archive Sidebar Position.
$wp_customize->add_setting(
	'timely_news_archive_sidebar_position',
	array(
		'sanitize_callback' => 'timely_news_sanitize_select',
		'default'           => 'right-sidebar',
	)
);

$wp_customize->add_control(
	'timely_news_archive_sidebar_position',
	array(
		'label'   => esc_html__( 'Archive Sidebar Position', 'timely-news' ),
		'section' => 'timely_news_sidebar_option',
		'type'    => 'select',
		'choices' => array(
			'right-sidebar' => esc_html__( 'Right Sidebar', 'timely-news' ),
			'no-sidebar'    => esc_html__( 'No Sidebar', 'timely-news' ),
		),
	)
);

// Sidebar Option - Post Sidebar Position.
$wp_customize->add_setting(
	'timely_news_post_sidebar_position',
	array(
		'sanitize_callback' => 'timely_news_sanitize_select',
		'default'           => 'right-sidebar',
	)
);

$wp_customize->add_control(
	'timely_news_post_sidebar_position',
	array(
		'label'   => esc_html__( 'Post Sidebar Position', 'timely-news' ),
		'section' => 'timely_news_sidebar_option',
		'type'    => 'select',
		'choices' => array(
			'right-sidebar' => esc_html__( 'Right Sidebar', 'timely-news' ),
			'no-sidebar'    => esc_html__( 'No Sidebar', 'timely-news' ),
		),
	)
);

// Sidebar Option - Page Sidebar Position.
$wp_customize->add_setting(
	'timely_news_page_sidebar_position',
	array(
		'sanitize_callback' => 'timely_news_sanitize_select',
		'default'           => 'right-sidebar',
	)
);

$wp_customize->add_control(
	'timely_news_page_sidebar_position',
	array(
		'label'   => esc_html__( 'Page Sidebar Position', 'timely-news' ),
		'section' => 'timely_news_sidebar_option',
		'type'    => 'select',
		'choices' => array(
			'right-sidebar' => esc_html__( 'Right Sidebar', 'timely-news' ),
			'no-sidebar'    => esc_html__( 'No Sidebar', 'timely-news' ),
		),
	)
);
