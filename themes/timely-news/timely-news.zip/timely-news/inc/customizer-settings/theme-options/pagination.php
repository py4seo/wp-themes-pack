<?php
/**
 * Pagination setting
 */

// Pagination setting.
$wp_customize->add_section(
	'timely_news_pagination',
	array(
		'title' => esc_html__( 'Pagination', 'timely-news' ),
		'panel' => 'timely_news_theme_options_panel',
	)
);

// Pagination enable setting.
$wp_customize->add_setting(
	'timely_news_pagination_enable',
	array(
		'default'           => true,
		'sanitize_callback' => 'timely_news_sanitize_checkbox',
	)
);

$wp_customize->add_control(
	new Timely_News_Toggle_Checkbox_Custom_control(
		$wp_customize,
		'timely_news_pagination_enable',
		array(
			'label'    => esc_html__( 'Enable Pagination.', 'timely-news' ),
			'settings' => 'timely_news_pagination_enable',
			'section'  => 'timely_news_pagination',
			'type'     => 'checkbox',
		)
	)
);

// Pagination - Pagination Style.
$wp_customize->add_setting(
	'timely_news_pagination_type',
	array(
		'default'           => 'numeric',
		'sanitize_callback' => 'timely_news_sanitize_select',
	)
);

$wp_customize->add_control(
	'timely_news_pagination_type',
	array(
		'label'           => esc_html__( 'Pagination Style', 'timely-news' ),
		'section'         => 'timely_news_pagination',
		'type'            => 'select',
		'choices'         => array(
			'default' => __( 'Default (Older/Newer)', 'timely-news' ),
			'numeric' => __( 'Numeric', 'timely-news' ),
		),
		'active_callback' => 'timely_news_pagination_enabled',
	)
);

/*========================Active Callback==============================*/
function timely_news_pagination_enabled( $control ) {
	return $control->manager->get_setting( 'timely_news_pagination_enable' )->value();
}
