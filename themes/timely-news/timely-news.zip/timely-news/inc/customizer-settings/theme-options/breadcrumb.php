<?php
/**
 * Breadcrumb settings
 */

$wp_customize->add_section(
	'timely_news_breadcrumb_section',
	array(
		'title' => esc_html__( 'Breadcrumb Options', 'timely-news' ),
		'panel' => 'timely_news_theme_options_panel',
	)
);

// Breadcrumb enable setting.
$wp_customize->add_setting(
	'timely_news_breadcrumb_enable',
	array(
		'default'           => true,
		'sanitize_callback' => 'timely_news_sanitize_checkbox',
	)
);
$wp_customize->add_control(
	new Timely_News_Toggle_Checkbox_Custom_control(
		$wp_customize,
		'timely_news_breadcrumb_enable',
		array(
			'label'    => esc_html__( 'Enable breadcrumb.', 'timely-news' ),
			'type'     => 'checkbox',
			'settings' => 'timely_news_breadcrumb_enable',
			'section'  => 'timely_news_breadcrumb_section',
		)
	)
);

// Breadcrumb - Separator.
$wp_customize->add_setting(
	'timely_news_breadcrumb_separator',
	array(
		'sanitize_callback' => 'sanitize_text_field',
		'default'           => '/',
	)
);

$wp_customize->add_control(
	'timely_news_breadcrumb_separator',
	array(
		'label'           => esc_html__( 'Separator', 'timely-news' ),
		'section'         => 'timely_news_breadcrumb_section',
		'active_callback' => function( $control ) {
			return ( $control->manager->get_setting( 'timely_news_breadcrumb_enable' )->value() );
		},
	)
);
