<?php

if ( ! get_theme_mod( 'timely_news_enable_posts_tag_section', false ) ) {
	return;
}

$section_content          = array();
$section_content['count'] = 5;
$section_content          = apply_filters( 'timely_news_posts_tag_section_content', $section_content );

timely_news_render_posts_tag_section( $section_content );

/**
 * Render tags section.
 */
function timely_news_render_posts_tag_section( $section_content ) {
	$title = get_theme_mod( 'timely_news_posts_tag_title', __( 'Posts Tag:', 'timely-news' ) );
	?>
    <div class="header-trending-tags">
        <div class="site-container-width">
            <div class="tag-container">
                <?php if ( ! empty( $title ) ) { ?>
                    <span class="tag-title"><?php echo esc_html( $title ); ?></span>
                <?php } ?>
                <div class="tags">
                    <?php
					$posttags = get_tags(
						array( 'number' => $section_content['count'] )
					);
					if ( $posttags ) {
						foreach ( $posttags as $tag ) {
							?>
							<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>"><?php echo esc_html( $tag->name ); ?></a>
							<?php
						}
					}
					?>
                </div>
            </div>
        </div>
    </div>
	<?php
}
