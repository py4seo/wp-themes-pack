<div class="banner-posts">
	<div class="banner-posts-wrapper">
		<?php
		$banner_posts_query = new WP_Query( $banner_posts_args );
		if ( $banner_posts_query->have_posts() ) {
			$i = 1;
			while ( $banner_posts_query->have_posts() ) :
				$banner_posts_query->the_post();
				?>
				<div class="single-card-container grid-card">
					<div class="single-card-image">
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
					</div>
					<div class="single-card-detail">
						<?php timely_news_categories_list(); ?>
						<h3 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						<?php if ( $i === 1 ) { ?>
							<div class="post-exerpt">
								<p><?php echo wp_kses_post( wp_trim_words( get_the_content(), 45 ) ); ?></p>
							</div>
						<?php } ?>
						<div class="card-meta">
							<?php
								timely_news_posted_by();
								timely_news_posted_on();
							?>
						</div>
					</div>
				</div>
				<?php
				$i++;
			endwhile;
			wp_reset_postdata();
		}
		?>
	</div>
</div>