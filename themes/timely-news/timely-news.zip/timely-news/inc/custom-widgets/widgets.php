<?php

// Featured Posts Widget.
require get_template_directory() . '/inc/custom-widgets/mini-list-widget.php';

// Grid List Posts Widget.
require get_template_directory() . '/inc/custom-widgets/grid-list-posts-widget.php';

// Grid Posts Widget.
require get_template_directory() . '/inc/custom-widgets/grid-posts-widget.php';

// Author Info Widget.
require get_template_directory() . '/inc/custom-widgets/info-author-widget.php';

// List Posts Widget.
require get_template_directory() . '/inc/custom-widgets/list-posts-widget.php';

// Social Widget.
require get_template_directory() . '/inc/custom-widgets/social-widget.php';

// Tile Posts Widget.
require get_template_directory() . '/inc/custom-widgets/tile-posts-widget.php';

/**
 * Register Widgets
 */
function timely_news_register_widgets() {

	register_widget( 'Timely_News_Mini_List_Widget' );

	register_widget( 'Timely_News_Grid_List_Posts_Widget' );

	register_widget( 'Timely_News_Grid_Posts_Widget' );

	register_widget( 'Timely_News_Author_Info_Widget' );

	register_widget( 'Timely_News_List_Posts_Widget' );

	register_widget( 'Timely_News_Social_Widget' );

	register_widget( 'Timely_News_Tile_Posts_Widget' );

}
add_action( 'widgets_init', 'timely_news_register_widgets' );
