<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );



// Login error echo
function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');






// Remove the link from the logo on the login page
add_action('login_head', function () {
    add_filter('login_headerurl', '__return_empty_string'); // Removes the URL
    add_filter('login_headertext', '__return_empty_string'); // Removes the text
});

// Disable the <a> element around the logo
add_action('login_enqueue_scripts', function () {
    echo '<style>
        .wp-login-logo > a {
            pointer-events: none; /* Disables link functionality */
            cursor: default; /* Removes link appearance */
        }
    </style>';
});

add_action('login_init', function () {
    if (isset($_GET['action']) && $_GET['action'] === 'lostpassword') {
        wp_redirect(home_url()); // Redirects to the homepage
        exit;
    }
});



function kelly_child_widgets_init_override() {

	// Footer Sidebar 1
	register_sidebar( array(
		'name'          => __( 'Footer Sidebar 1', 'kelly' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		// здесь можешь изменить тег/классы заголовка, если нужно
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	// Footer Sidebar 2
	register_sidebar( array(
		'name'          => __( 'Footer Sidebar 2', 'kelly' ),
		'id'            => 'sidebar-2',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	// Footer Sidebar 3
	register_sidebar( array(
		'name'          => __( 'Footer Sidebar 3', 'kelly' ),
		'id'            => 'sidebar-3',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'kelly_child_widgets_init_override', 20 );



if ( ! function_exists( 'kelly_content_nav' ) ) :
/**
 * Display navigation to next/previous pages when applicable
 * (переопределено в дочерней теме)
 */
function kelly_content_nav( $nav_id ) {
	global $wp_query, $post;

	// Don't print empty markup on single pages if there's nowhere to navigate.
	if ( is_single() ) {
		$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
		$next     = get_adjacent_post( false, '', false );

		if ( ! $next && ! $previous ) {
			return;
		}
	}

	// Don't print empty markup in archives if there's only one page.
	if ( $wp_query->max_num_pages < 2 && ( is_home() || is_archive() || is_search() ) ) {
		return;
	}

	$nav_class = ( is_single() ) ? 'post-navigation' : 'paging-navigation';
	?>
	<nav role="navigation" id="<?php echo esc_attr( $nav_id ); ?>" class="<?php echo esc_attr( $nav_class ); ?>">
		<h2 class="screen-reader-text"><?php _e( 'Post navigation', 'kelly' ); ?></h2>

	<?php if ( is_single() ) : // navigation links for single posts ?>

		<?php previous_post_link(
			'<div class="nav-previous">%link</div>',
			'<span class="meta-nav">' . _x( '&larr;', 'Previous post link', 'kelly' ) . '</span> %title'
		); ?>

		<?php next_post_link(
			'<div class="nav-next">%link</div>',
			'%title <span class="meta-nav">' . _x( '&rarr;', 'Next post link', 'kelly' ) . '</span>'
		); ?>

	<?php elseif ( $wp_query->max_num_pages > 1 && ( is_home() || is_archive() || is_search() ) ) : // navigation links for home, archive, and search pages ?>

		<?php if ( get_next_posts_link() ) : ?>
			<div class="nav-previous">
				<?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts', 'kelly' ) ); ?>
			</div>
		<?php endif; ?>

		<?php if ( get_previous_posts_link() ) : ?>
			<div class="nav-next">
				<?php previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>', 'kelly' ) ); ?>
			</div>
		<?php endif; ?>

	<?php endif; ?>

	</nav><!-- #<?php echo esc_html( $nav_id ); ?> -->
	<?php
}
endif;
