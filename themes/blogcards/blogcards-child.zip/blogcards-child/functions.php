<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );


function custom_excerpt_length($content) {
    global $post;
    $content = get_the_content();
    $trimmed_content = mb_substr($content, 0, 550) . '...';
    return $trimmed_content;
}

add_filter('the_excerpt', 'custom_excerpt_length', 10);
add_filter('get_the_excerpt', 'custom_excerpt_length', 10);
add_filter('wp_trim_excerpt', 'custom_excerpt_length', 10);



function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');



/*  Site name/logo
/* ------------------------------------ */
if ( ! function_exists( 'blogcards_site_title' ) ) {

	function blogcards_site_title() {

		$site_name      = get_bloginfo( 'name' );
		$custom_logo_id = get_theme_mod( 'custom_logo' );
		$logo_src       = $custom_logo_id ? wp_get_attachment_image_src( $custom_logo_id, 'full' ) : false;

		// Тег заголовка: H1 на главной/блоге, иначе P
		$title_tag = ( is_front_page() || is_home() ) ? 'h1' : 'p';

		// Если есть логотип — выводим его отдельно от заголовка в едином контейнере
		if ( function_exists( 'has_custom_logo' ) && has_custom_logo() && ! empty( $logo_src[0] ) ) {

			$out  = '<div class="site-title-wrap">' . "\n";
			$out .= '  <a class="site-logo" href="' . esc_url( home_url( '/' ) ) . '" rel="home">'
			      . '    <img src="' . esc_url( $logo_src[0] ) . '" alt="' . esc_attr( $site_name ) . '">'
			      . '  </a>' . "\n";

			$out .= '  <' . $title_tag . ' class="site-title">'
			      . '    <a href="' . esc_url( home_url( '/' ) ) . '" rel="home">' . esc_html( $site_name ) . '</a>'
			      . '  </' . $title_tag . '>' . "\n";

			$out .= '</div>' . "\n";

			return $out;
		}

		// Фолбэк: логотипа нет — старое поведение (только текст внутри заголовка)
		$link = '<a href="' . esc_url( home_url( '/' ) ) . '" rel="home">' . esc_html( $site_name ) . '</a>';

		if ( is_front_page() || is_home() ) {
			$sitename = '<h1 class="site-title">' . $link . '</h1>' . "\n";
		} else {
			$sitename = '<p class="site-title">' . $link . '</p>' . "\n";
		}

		return $sitename;
	}

}
