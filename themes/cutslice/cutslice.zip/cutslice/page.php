<?php get_header(); ?>

<div class="content">
	<div class="content-inner group">
		<?php while ( have_posts() ): the_post(); ?>
		
		<article <?php post_class('article-type-list group'); ?>>	
			
			<div class="type-list-outer group">
				<div class="type-list-inner">	
			
					<div class="post-wrapper group">
						<header class="entry-header group">
							<h1 class="entry-title"><?php the_title(); ?></h1>
						</header>
						<div class="entry-content">
							<div class="entry themeform">
								<?php the_content(); ?>
								<div class="clear"></div>
							</div><!--/.entry-->
						</div>
						<div class="entry-footer group">
							<?php if ( comments_open() || get_comments_number() ) :	comments_template( '/comments.php', true ); endif; ?>
						</div>
					</div>
			
				</div>
			</div>
			
		</article><!--/.post-->	
		
		<?php endwhile; ?>
	</div>
</div><!--/.content-->

<div id="move-sidebar-content"></div>

<?php get_footer(); ?>