<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );


function custom_excerpt_length($content) {
    global $post;
    $content = get_the_content();
    $trimmed_content = mb_substr($content, 0, 450) . '...';
    return $trimmed_content;
}

add_filter('the_excerpt', 'custom_excerpt_length', 10);
add_filter('get_the_excerpt', 'custom_excerpt_length', 10);
add_filter('wp_trim_excerpt', 'custom_excerpt_length', 10);



function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');



if ( ! function_exists( 'cutslice_site_title' ) ) {
	function cutslice_site_title() {
		$custom_logo_id = get_theme_mod( 'custom_logo' );
		$logo           = wp_get_attachment_image_src( $custom_logo_id, 'full' );
		$home           = esc_url( home_url( '/' ) );
		$name           = get_bloginfo( 'name' );
		$tag            = ( is_front_page() || is_home() ) ? 'h1' : 'p';

		$out  = '<div class="site-title">';
		if ( has_custom_logo() && $logo && ! empty( $logo[0] ) ) {
			$out .= '<a href="' . $home . '" rel="home"><img src="' . esc_url( $logo[0] ) . '" alt="' . esc_attr( $name ) . '"></a>';
		}

		if ( $name ) {
			if ( display_header_text() ) {
				$out .= '<' . $tag . '><a href="' . $home . '" rel="home">' . esc_html( $name ) . '</a></' . $tag . '>';
			} else {
				$out .= '<' . $tag . ' style="position:absolute!important;width:1px!important;height:1px!important;overflow:hidden!important;clip:rect(1px,1px,1px,1px)!important;white-space:nowrap!important;margin:0!important;padding:0!important;border:0!important;"><a href="' . $home . '" rel="home"><span>' . esc_html( $name ) . '</span></a></' . $tag . '>';
			}
		}

		$out .= '</div>';
		return $out;
	}
}

