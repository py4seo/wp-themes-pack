<?php 

 ?>

</div> <!-- / wrapper -->
<div class="site-navigation-overlay"></div>

<p class="footer-center">Copyright &copy; <?php echo date('Y'); ?> | All rights reserved by <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
</body>
</html>