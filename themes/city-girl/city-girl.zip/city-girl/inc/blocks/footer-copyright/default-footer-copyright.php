<?php

function city_girl_get_default_footer_copyright()
{
    return "";
}
