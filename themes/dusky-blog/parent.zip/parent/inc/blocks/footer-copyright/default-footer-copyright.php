<?php

function dusky_blog_get_default_footer_copyright() {
    return "";
}