				<footer id="colophon" role="contentinfo">

					<div id="site-generator">
						<p>&copy; 2011 - <?php echo date('Y'); ?> | <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
					</div>

				</footer><!-- #colophon -->
			</div><!-- #main -->
    	</div><!-- #inner-wrapper -->
    </div><!-- #wrapper -->
</div><!-- #page-->

<?php wp_footer(); ?>

</body>
</html>