<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );




// Login error echo
function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');






// Remove the link from the logo on the login page
add_action('login_head', function () {
    add_filter('login_headerurl', '__return_empty_string'); // Removes the URL
    add_filter('login_headertext', '__return_empty_string'); // Removes the text
});

// Disable the <a> element around the logo
add_action('login_enqueue_scripts', function () {
    echo '<style>
        .wp-login-logo > a {
            pointer-events: none; /* Disables link functionality */
            cursor: default; /* Removes link appearance */
        }
    </style>';
});

add_action('login_init', function () {
    if (isset($_GET['action']) && $_GET['action'] === 'lostpassword') {
        wp_redirect(home_url()); // Redirects to the homepage
        exit;
    }
});