	</div><!-- .wrapper -->

</div><!-- .wrapper-inner -->

<p class="copyr">Copyright &copy; 2015 - <?php echo date('Y'); ?> | All rights reserved by <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>

</body>
</html>