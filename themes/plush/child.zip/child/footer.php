<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package plush
 */
?>


<?php 
$copyright = get_theme_mod( 'footer_copyright_text', plush_get_default_footer_copyright() );
?>

	<footer id="colophon" class="site-footer">

		<div class="container">

			<?php 
get_template_part( 'template-parts/social', 'links' );
?>

			<div class="site-info">
				<?php 
?>
					<a rel="nofollow" href="<?php 
echo  esc_url( '' ) ;
?>">
<p>Copyright &copy; <?php echo date('Y'); ?> | All rights reserved by <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
					</a>
					<span class="sep">  </span>
</div>
			</div><!-- .site-info -->
		</div>
	</footer><!-- #colophon -->


<a class="scroll-to-top" href="javascript:void(0)">
<svg id="Layer_1"  version="1.1" viewBox="0 0 64 64" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
	<g><g id="Icon-Chevron-Left" transform="translate(237.000000, 335.000000)"><polyline class="st0" id="Fill-35" points="-191.3,-296.9 -193.3,-294.9 -205,-306.6 -216.7,-294.9 -218.7,-296.9 -205,-310.6      -191.3,-296.9    "/></g></g></svg>
</a>

<?php 
wp_footer();
?>

</body>
</html>
