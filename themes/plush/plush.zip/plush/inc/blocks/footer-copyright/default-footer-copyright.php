<?php

function plush_get_default_footer_copyright() {
    return "";
}