</div><!-- .main -->
<?php
if ( ! is_page_template( 'full-width.php' ) ) {
	get_sidebar( 'primary' );
}
?>
</div><!-- .overflow-container -->
<?php 
// Elementor `footer` location
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) :
?>
<footer id="site-footer" class="site-footer" role="contentinfo">
	<h2>
		<a href="<?php echo esc_url( home_url() ); ?>">
			<?php bloginfo( 'title' ); ?>
		</a>
	</h2>
	<?php
	if ( get_bloginfo( 'description' ) ) {
		echo '<span class="tagline">' . esc_html( get_bloginfo( "description" ) ) . '</span>';
	}
	?>
	<div class="design-credit">
        <span>
<p>&copy; <?php echo date('Y'); ?> | All rights reserved by <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
        </span>
	</div>
</footer>
<?php endif; ?>
<?php do_action( 'ct_ignite_body_bottom' ); ?>
<?php wp_footer(); ?>
</body>
</html>