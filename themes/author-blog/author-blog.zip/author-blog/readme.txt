=== Author Blog ===
Contributors: SmarterThemes.com
Tags: blog, author, book, novel, publishing, news, e-commerce, grid-layout, one-column, two-columns, three-columns, four-Columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, footer-widgets, flexible-header, theme-options, translation-ready, featured-images, block-styles, wide-blocks, sticky-post, featured-image-header, front-page-post-form, full-width-template
Requires at least: 5.0
Tested up to: 6.6
Requires PHP: 5.6
Stable tag: 2.1.18
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Author Blog is a feature-rich WordPress theme designed for authors, fiction and non-fiction writers, novelists, poets, publisher who want to reach the world with their website and blog.  Whether writing about fiction, non-fiction or any other interest, you'll find Author Blog is perfect for highlighting your content and providing a smooth modern, and easy to use experience while always keeping your book front and center for your readers.

== Frequently Asked Questions ==

= How to Install Theme =
1. In your admin panel, go to Appearance > Themes and click the Add New button and Search for Author Blog, OR
2. If you have theme zip file, click Upload and choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==
= 1.0.0 - March 20, 2021 =
* Initial release

= 1.0.1 - April 16, 2021 =
* Solved Theme Uri Issue
* Solved Search Icon Focus Issue
* Removed Commented Code
* Solved Default Social Icon Issues
* Checked compatiblity with WordPress 5.7.1
* TGM Translation Ready
* Dropdown Menu Navigation on Mobile view

= 1.0.2 - April 30, 2021 =
* Removed Search Icon From Menu

= 1.0.4 - May 27, 2021 =
* Removed Footer Icon
* Checked Compatiblity With WordPress 5.7.2
* Removed Getting Started Page
* Removed Blank Footer Section
* Removed Unused Theme Options

= 1.0.5 - Jun 21, 2021 =
* Solved a big error.

= 1.0.6 - January 07, 2022 =
* Imprved Getting Started Page
* Compatibility Checked With All Latest Recommeded Plugins and WordPress 5.8.3

= 1.0.7 - March 10, 2022 =
* Solved The Theme Check Recommended Error
* Removed Add Editor Style. casue, it was in the wrong path.
* Checked Compatibility With WordPress 5.9 and It's recommended Plugins
* Solved Menu right White Space Issue
* Added Masonry Layout and solved Post Overlaping Issue.

= 1.0.8 - April 19, 2022 =
* Solved Some Minor Issues
* Checked Comptibility with WordPress 5.9.3
* Checked Compatibility With WooCommerce

= 1.0.9 - April 19, 2022 =
* Added Compatibility With RS WP BOOKS SHOWCASE
* Improved Code Quality

= 2.0.0 - July 26, 2022 =
* Checked Compatibility with WordPress 6.0.1
* Removed Tgm Plugin Activation

= 2.0.1 - September 02, 2022 =
* Fix Search Button width

= 2.0.2 - September 03, 2022 =
* Removed hard-coded links
* Removed found iframe

= 2.0.3 - September 05, 2022 =
* Added reference to register_block_style, register_block_pattern and add_editor_style()
* Checked Compatibility with WordPress 6.0.2

= 2.0.4 - September 08, 2022 =
* Fixed getting started page.

= 2.0.5 - November 01, 2022 =
* Checked Compatibility with WordPress 6.0.3

= 2.0.6 - November 08, 2022 =
* Checked Compatibility with WordPress 6.1

= 2.0.7 - November 15, 2022 =
* Checked Compatibility with other plugins

= 2.0.8 - November 22, 2022 =
* Checked Compatibility with WordPress 6.1.1

= 2.0.9 - March 22, 2023 =
* fixed UI issues

= 2.1.0 - April 24, 2023 =
* Update admin notices after install

= 2.1.1 - April 25, 2023 =
* Removed Upgrade to Pro and get started notices

= 2.1.2 - June 01, 2023 =
* Monthly Updates

= 2.1.3 - June 16, 2023 =
* Monthly Updates

= 2.1.4 - July 07, 2023 =
* Monthly Updates

= 2.1.5 - July 26, 2023 =
* Monthly Updates

= 2.1.6 - August 8, 2023 =
* Monthly Updates

= 2.1.7 - August 21, 2023 =
* Monthly Updates

= 2.1.8 - September 06, 2023 =
* Monthly Updates

= 2.1.9 - September 19, 2023 =
* Monthly Updates

= 2.1.10 - October 13, 2023 =
* Monthly Updates

= 2.1.11 - November 11, 2023 =
* Monthly Updates

= 2.1.12 - December 08, 2023 =
* Monthly Updates

= 2.1.13 - January 08, 2024 =
* Monthly Updates

= 2.1.14 - February 05, 2024 =
* Monthly Updates

= 2.1.15 - April 09, 2024 =
* Monthly Updates

= 2.1.16 - May 31, 2024 =
* Added Demo content
* Make it compatible with RS WP BOOK Showcase

= 2.1.17 - Jun 30, 2024 =
* Added Header Options

= 2.1.18 - July 28, 2024 =
* Checked Compatibility with Latest WordPress 6.6.1
* Added Go Pro Option in Customizer Screen
* Solved style of admin widget

== Copyright ==
Author Blog WordPress Theme, Copyright 2024 BookMockups.com
Author Blog is distributed under the terms of the GNU GPL
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Author Blog bundles the following third-party resources:
* Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License Version 2 or later.
* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
* CSS bootstrap.css
  Copyright 2011-2020 The Bootstrap Authors
  Copyright 2011-2020 Twitter, Inc.
  Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
* Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
  License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
* Owl Carousel v2.3.4
  Copyright 2013-2018 David Deutsch
  Licensed under: SEE LICENSE IN https://github.com/OwlCarousel2/OwlCarousel2/blob/master/LICENSE
* imagesLoaded PACKAGED v5.0.0
  Copyright (c) 2011-2022 David DeSandro and contributors
  Licensed under: SEE LICENSE IN https://github.com/desandro/imagesloaded/blob/master/LICENSE.md
* TGM Plugin Activation is licensed under the GPL-2.0+
  http://tgmpluginactivation.com/
  Authors: Thomas Griffin, Gary Jones, Juliette Reinders Folmer
  Copyright (c) 2011, Thomas Griffin

== License/copyright for images ==
* logo.png self created.
* Screenshot images are all licensed under CC0 Universal

Image for theme screenshot
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/846852

Image for theme screenshot
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1082806

Image for theme screenshot
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/848583

Image for theme screenshot
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/912411

Image for theme screenshot
License: CC0 1.0 Universal (CC0 1.0)
License URL: https://pxhere.com/en/license
Source: https://pxhere.com/en/photo/1081678

