(function (api) {

	// Extends our custom "Writers Portfolio" section.
	api.sectionConstructor['author-blog'] = api.Section.extend({

		// No events for this type of section.
		attachEvents: function () {},

		// Always make the section active.
		isContextuallyActive: function () {
			return true;
		}
	});
	// jQuery("#accordion-panel-author-blog-theme-options").addClass("custom-class");

})(wp.customize);