<?php
$wp_customize->add_setting(
	'tagline_above_title',
	array(
		'transport'            => 'refresh',
		'capability'           => 'edit_theme_options',
		'sanitize_callback'     => 'author_blog_sanitize_checkbox',
		'default'     => false,
	)
);

$wp_customize->add_control(
	'tagline_above_title',
	array(
		'label'       => __( 'Display Tagline Above title', 'author-blog' ),
		'section'     => 'title_tagline',
		'type'        => 'checkbox',
	)
);

$wp_customize->add_setting(
	'site_header_height',
	array(
		'transport'            => 'refresh',
		'capability'           => 'edit_theme_options',
		'sanitize_callback'     => 'author_blog_sanitize_number_absint',
		'default'     => '',
	)
);

$wp_customize->add_control(
	'site_header_height',
	array(
		'label'       => __( 'Header Hight', 'author-blog' ),
		'section'     => 'header_image',
		'type'        => 'number',
	)
);

$wp_customize->add_setting(
	'header_text_style',
	array(
		'transport'            => 'refresh',
		'capability'           => 'edit_theme_options',
		'sanitize_callback'     => 'author_blog_sanitize_select',
		'default'     => 'default',
	)
);

$wp_customize->add_control(
	'header_text_style',
	array(
		'label'       => __( 'Header Text Layout', 'author-blog' ),
		'section'     => 'header_image',
		'type'        => 'select',
		'choices' => array(
			'default' => __( 'Default', 'author-blog' ),
			'with-bg' => __( 'Header Text With BG', 'author-blog' ),
		),
	)
);

$wp_customize->add_setting(
	'header_text_v_align',
	array(
		'transport'            => 'refresh',
		'capability'           => 'edit_theme_options',
		'sanitize_callback'     => 'author_blog_sanitize_select',
		'default'     => 'center',
	)
);

$wp_customize->add_control(
	'header_text_v_align',
	array(
		'label'       => __( 'Header Text Vertical Align', 'author-blog' ),
		'section'     => 'header_image',
		'type'        => 'select',
		'choices' => array(
			'start' => __( 'Top', 'author-blog' ),
			'center' => __( 'Middle', 'author-blog' ),
			'end' => __( 'Bottom', 'author-blog' ),
		),
	)
);

$wp_customize->add_setting(
	'header_text_h_align',
	array(
		'transport'            => 'refresh',
		'capability'           => 'edit_theme_options',
		'sanitize_callback'     => 'author_blog_sanitize_select',
		'default'     => 'center',
	)
);

$wp_customize->add_control(
	'header_text_h_align',
	array(
		'label'       => __( 'Header Text Horizontal Align', 'author-blog' ),
		'section'     => 'header_image',
		'type'        => 'select',
		'choices' => array(
			'start' => __( 'left', 'author-blog' ),
			'center' => __( 'Center', 'author-blog' ),
			'end' => __( 'Right', 'author-blog' ),
		),
	)
);

$wp_customize->add_setting(
	'header_text_align',
	array(
		'transport'            => 'refresh',
		'capability'           => 'edit_theme_options',
		'sanitize_callback'     => 'author_blog_sanitize_select',
		'default'     => 'center',
	)
);

$wp_customize->add_control(
	'header_text_align',
	array(
		'label'       => __( 'Header Text Align', 'author-blog' ),
		'section'     => 'header_image',
		'type'        => 'select',
		'choices' => array(
			'left' => __( 'left', 'author-blog' ),
			'right' => __( 'right', 'author-blog' ),
			'center' => __( 'center', 'author-blog' ),
		),
	)
);