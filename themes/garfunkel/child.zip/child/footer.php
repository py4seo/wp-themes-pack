		<footer class="credits">

			<p>Copyright &copy; <?php echo date('Y'); ?> | All rights reserved by <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
				
		</footer><!-- .credits -->

		<?php wp_footer(); ?>

	</body>
</html>