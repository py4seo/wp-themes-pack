<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );



function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');




if ( ! function_exists( 'blogside_site_title' ) ) {
	function blogside_site_title() {
		$custom_logo_id = get_theme_mod( 'custom_logo' );
		$logo           = wp_get_attachment_image_src( $custom_logo_id, 'full' );
		$home_url       = esc_url( home_url( '/' ) );
		$site_name      = get_bloginfo( 'name' );
		$tag            = ( is_front_page() || is_home() ) ? 'h1' : 'p';

		$out  = '<div class="site-title">';
		if ( has_custom_logo() && $logo && ! empty( $logo[0] ) ) {
			$out .= '<a href="' . $home_url . '" rel="home"><img src="' . esc_url( $logo[0] ) . '" alt="' . esc_attr( $site_name ) . '"></a>';
		}

		$out .= '<' . $tag . '><a href="' . $home_url . '" rel="home">'
		      . ( display_header_text()
					? esc_html( $site_name )
					: '<span class="screen-reader-text">' . esc_html( $site_name ) . '</span>' )
		      . '</a></' . $tag . '>';

		$out .= '</div>';
		return $out;
	}
}
