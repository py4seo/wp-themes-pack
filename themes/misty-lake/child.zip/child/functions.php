<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );




if ( ! function_exists( 'mistylake_content_nav' ) ) :
function mistylake_content_nav( $nav_id ) {
	global $wp_query, $post;

	// Don't print empty markup on single pages if there's nowhere to navigate.
	if ( is_single() ) {
		$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
		$next     = get_adjacent_post( false, '', false );

		if ( ! $next && ! $previous ) {
			return;
		}
	}

	// Don't print empty markup in archives if there's only one page.
	if ( $wp_query->max_num_pages < 2 && ( is_home() || is_archive() || is_search() ) ) {
		return;
	}

	$nav_class = 'site-navigation paging-navigation';
	if ( is_single() ) {
		$nav_class = 'site-navigation post-navigation';
	}
	?>
	<nav role="navigation" id="<?php echo esc_attr( $nav_id ); ?>" class="<?php echo esc_attr( $nav_class ); ?>">
		<h2 class="assistive-text screen-reader-text">
			<?php esc_html_e( 'Post navigation', 'mistylake' ); ?>
		</h2>

	<?php if ( is_single() ) : // navigation links for single posts ?>

		<?php previous_post_link(
			'<div class="nav-previous">%link</div>',
			'<span class="meta-nav">' . _x( '&larr;', 'Previous post link', 'mistylake' ) . '</span> %title'
		); ?>

		<?php next_post_link(
			'<div class="nav-next">%link</div>',
			'%title <span class="meta-nav">' . _x( '&rarr;', 'Next post link', 'mistylake' ) . '</span>'
		); ?>

	<?php elseif ( $wp_query->max_num_pages > 1 && ( is_home() || is_archive() || is_search() ) ) : // navigation links for home, archive, and search pages ?>

		<?php if ( get_next_posts_link() ) : ?>
			<div class="nav-previous">
				<?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts', 'mistylake' ) ); ?>
			</div>
		<?php endif; ?>

		<?php if ( get_previous_posts_link() ) : ?>
			<div class="nav-next">
				<?php previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>', 'mistylake' ) ); ?>
			</div>
		<?php endif; ?>

	<?php endif; ?>

	</nav><!-- #<?php echo esc_html( $nav_id ); ?> -->
	<?php
}
endif;