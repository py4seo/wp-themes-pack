<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );



//Excerpt

function custom_excerpt_length($content) {
    global $post;
    $content = get_the_content();
    $trimmed_content = mb_substr($content, 0, 350) . '...';
    return $trimmed_content;
}

add_filter('the_excerpt', 'custom_excerpt_length', 10);
add_filter('get_the_excerpt', 'custom_excerpt_length', 10);
add_filter('wp_trim_excerpt', 'custom_excerpt_length', 10);


// Login error echo
function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');






// Remove the link from the logo on the login page
add_action('login_head', function () {
    add_filter('login_headerurl', '__return_empty_string'); // Removes the URL
    add_filter('login_headertext', '__return_empty_string'); // Removes the text
});

// Disable the <a> element around the logo
add_action('login_enqueue_scripts', function () {
    echo '<style>
        .wp-login-logo > a {
            pointer-events: none; /* Disables link functionality */
            cursor: default; /* Removes link appearance */
        }
    </style>';
});

add_action('login_init', function () {
    if (isset($_GET['action']) && $_GET['action'] === 'lostpassword') {
        wp_redirect(home_url()); // Redirects to the homepage
        exit;
    }
});




// Adjust .entry-title heading tags using output buffering
add_action( 'template_redirect', 'me_adjust_entry_title_heading' );

function me_adjust_entry_title_heading() {
    // Do nothing in admin area
    if ( is_admin() ) {
        return;
    }

    // On the front page we want H1 (theme outputs H2 → convert H2 to H1)
    if ( is_front_page() ) {
        ob_start( 'me_frontpage_entry_title_h2_to_h1' );
    } else {
        // On all other pages theme outputs H1 → convert H1 to H2
        ob_start( 'me_frontpage_entry_title_h2_to_h1' );
    }
}

/**
 * For inner pages: convert <h1 class="entry-title"> to <h2 class="entry-title">
 */
function me_inner_entry_title_h1_to_h2( $html ) {
    $html = preg_replace(
        '#<h1\s+class="entry-title">(.*?)</h1>#si',
        '<h2 class="entry-title">$1</h2>',
        $html
    );

    return $html;
}

/**
 * For front page: convert <h2 class="entry-title"> to <h1 class="entry-title">
 */
function me_frontpage_entry_title_h2_to_h1( $html ) {
    $html = preg_replace(
        '#<h2\s+class="entry-title">(.*?)</h2>#si',
        '<h1 class="entry-title">$1</h1>',
        $html
    );

    return $html;
}

