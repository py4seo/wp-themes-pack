<!DOCTYPE html>

<html class="no-js" <?php language_attributes(); ?>>

	<head profile="http://gmpg.org/xfn/11">
		
		<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" >
		 
		<?php wp_head(); ?>
	
	</head>
	
	<body <?php body_class(); ?>>

		<?php 
		if ( function_exists( 'wp_body_open' ) ) {
			wp_body_open(); 
		}
		?>

		<a class="skip-link button" href="#site-content"><?php _e( 'Skip to the content', 'fukasawa' ); ?></a>
	
		<div class="mobile-navigation">
	
			<ul class="mobile-menu">
						
				<?php 
				if ( has_nav_menu( 'primary' ) ) {
																	
					$primary_nav = wp_nav_menu( array( 
						'container' 		=> '', 
						'echo'				=> false,
						'items_wrap' 		=> '%3$s',
						'theme_location' 	=> 'primary'
					) );

					echo $primary_nav;

				} else {

					$pages_list = wp_list_pages( array(
						'container' => '',
						'echo'		=> false,
						'title_li' 	=> ''
					) );

					echo $pages_list;
					
				} 
				?>
				
			 </ul>
		 
		</div><!-- .mobile-navigation -->
	
		<div class="sidebar">
		
			<?php

$title_tag = ( is_front_page() || is_home() ) ? 'h1' : 'div';

$custom_logo_id  = get_theme_mod( 'custom_logo' );
$legacy_logo_url = get_theme_mod( 'fukasawa_logo' );
$site_name       = get_bloginfo( 'name' );


if ( $custom_logo_id || $legacy_logo_url ) :
	$logo_url = $custom_logo_id ? wp_get_attachment_image_url( $custom_logo_id, 'full' ) : $legacy_logo_url;
	?>
	<div class="blog-logo">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<img src="<?php echo esc_url( $logo_url ); ?>"
			     alt="" role="presentation"
			     <?php echo ( $title_tag === 'h1' ) ? 'fetchpriority="high" decoding="async"' : 'loading="lazy" decoding="async"'; ?> />
		</a>
	</div>
<?php endif; ?>

<?php

if ( $site_name ) : ?>
	<<?php echo $title_tag; ?> class="blog-title">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php echo esc_html( $site_name ); ?>
		</a>
	</<?php echo $title_tag; ?>>
<?php endif; ?>

			
			<button type="button" class="nav-toggle">
			
				<div class="bars">
					<div class="bar"></div>
					<div class="bar"></div>
					<div class="bar"></div>
				</div>
				
				<p>
					<span class="menu"><?php _e( 'Menu', 'fukasawa' ); ?></span>
					<span class="close"><?php _e( 'Close', 'fukasawa' ); ?></span>
				</p>
			
			</button>
			
			<ul class="main-menu">
				<?php echo isset( $primary_nav ) ? $primary_nav : $pages_list; ?>
			</ul><!-- .main-menu -->

			<?php if ( is_active_sidebar( 'sidebar' ) ) : ?>
				<div class="widgets">
					<?php dynamic_sidebar( 'sidebar' ); ?>
				</div><!-- .widgets -->
			<?php endif; ?>

			<div class="credits">
				<p>&copy; <?php echo date( 'Y' ); ?> <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>.</p>
			</div><!-- .credits -->
							
		</div><!-- .sidebar -->
	
		<main class="wrapper" id="site-content">