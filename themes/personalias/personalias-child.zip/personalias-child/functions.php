<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );


function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');

add_action('login_enqueue_scripts', function() {
    echo '<style>.login h1 a { pointer-events: none; }</style>';
});

add_action('login_enqueue_scripts', function() {
    echo '<style>.login #nav { display: none; }</style>';
});






// Remove the link from the logo on the login page
add_action('login_head', function () {
    add_filter('login_headerurl', '__return_empty_string'); // Removes the URL
    add_filter('login_headertext', '__return_empty_string'); // Removes the text
});

// Disable the <a> element around the logo
add_action('login_enqueue_scripts', function () {
    echo '<style>
        .wp-login-logo > a {
            pointer-events: none; /* Disables link functionality */
            cursor: default; /* Removes link appearance */
        }
    </style>';
});

add_action('login_init', function () {
    if (isset($_GET['action']) && $_GET['action'] === 'lostpassword') {
        wp_redirect(home_url()); // Redirects to the homepage
        exit;
    }
});



function custom_excerpt_length($content) {
    global $post;
    $content = get_the_content();
    $trimmed_content = mb_substr($content, 0, 350) . '...';
    return $trimmed_content;
}

add_filter('the_excerpt', 'custom_excerpt_length', 10);
add_filter('get_the_excerpt', 'custom_excerpt_length', 10);
add_filter('wp_trim_excerpt', 'custom_excerpt_length', 10);


/*  Site name/logo
/* ------------------------------------ */
if ( ! function_exists( 'personalias_site_title' ) ) {

	function personalias_site_title() {

		$custom_logo_id = get_theme_mod( 'custom_logo' );
		$logo_src       = wp_get_attachment_image_src( $custom_logo_id, 'full' );

		$tag = ( is_front_page() || is_home() ) ? 'h1' : 'p';


		$home_url  = esc_url( home_url( '/' ) );
		$site_name = get_bloginfo( 'name' );


		$out  = '<div class="site-title">' . "\n";

		if ( has_custom_logo() && $logo_src && ! empty( $logo_src[0] ) ) {
			$out .= '  <a href="' . $home_url . '" rel="home">'
			      . '    <img src="' . esc_url( $logo_src[0] ) . '" alt="' . esc_attr( $site_name ) . '">'
			      . '  </a>' . "\n";
		}


		$out .= '  <' . $tag . '>'
		      . '    <a href="' . $home_url . '" rel="home">' . esc_html( $site_name ) . '</a>'
		      . '  </' . $tag . '>' . "\n";

		$out .= '</div>' . "\n";

		return $out;
	}

}

