<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Almighty
 */

?>

</div><!-- #content -->
<?php
if ((is_front_page() || is_home()) && !is_paged() ) {
    do_action('almighty_action_featured_page');
}
?>

<footer id="colophon" class="site-footer">
<?php if (is_active_sidebar('footer-col-1') || is_active_sidebar('footer-col-2') || is_active_sidebar('footer-col-3')) { ?>
    <div class="site-widget-area clear">
        <div class="wrapper">
            <div class="row">
                    <?php if (is_active_sidebar('footer-col-1')) : ?>
                        <div class="col col-three-1">
                            <?php dynamic_sidebar('footer-col-1'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('footer-col-2')) : ?>
                        <div class="col col-three-1">
                            <?php dynamic_sidebar('footer-col-2'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('footer-col-3')) : ?>
                        <div class="col col-three-1">
                            <?php dynamic_sidebar('footer-col-3'); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php } ?>

    <?php if (has_nav_menu('social')) : ?>
        <div class="footer-social-menu">
            <div class="wrapper">
                <div class="row">
                    <div class="col col-full">
                        <div class="social-navigation" role="navigation" aria-label="<?php esc_attr_e('Footer Social Links Menu', 'almighty'); ?>">
                            <?php
                            wp_nav_menu(array(
                                'theme_location' => 'social',
                                'menu_class' => 'social-links-menu',
                                'depth' => 1,
                                'link_before' => '<span class="icon-label">',
                                'link_after' => '</span>' . almighty_get_svg(array('icon' => 'chain')),
                            ));
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="site-info clear">
        <div class="wrapper">
            <div class="row">
                <div class="col col-full">
                    <div class="copyright-info">
                    <p>&copy; <?php echo date('Y'); ?> | All rights reserved by <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<button class="scroll-up">
    <span class="screen-reader-text"><?php echo esc_html('Scroll up','almighty'); ?></span>
</button>
</div>

<?php wp_footer(); ?>

</body>
</html>
