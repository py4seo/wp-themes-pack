=== Almighty ===
Contributors: unitedtheme
Requires at least: 5.3
Tested up to: 6.8
Requires PHP: 5.6
Stable tag: 1.3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Almighty is a Modern clean WordPress Blog free theme for all the Blogger out there who strive towards minimalism and clean lines. Its retina ready and fully responsive design will look amazing, and work fluently, on all devices (mobile, tablet, and desktop). Almighty features multiple blog layouts to choose from and tons of options for customizing the theme and making it your own. See your changes in real-time using the easy to use built-in theme customizer.

Tags: blog, news, entertainment, two-columns, left-sidebar, right-sidebar, featured-image-header, custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Almighty includes support for Infinite Scroll in Jetpack.

== Copyright ==

Almighty WordPress Theme, (C) 2025 UnitedTheme
Almighty is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Credits ==

Unless otherwise specified, all the theme files and scripts are licensed under GNU General Public License.

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)

* Google Fonts:

   Roboto (https://fonts.google.com/specimen/Roboto)
   Licensed under Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)
   Copyright Christian Robertson


   Oswald (https://fonts.google.com/specimen/Oswald)
   Licensed under SIL Open Font License, 1.1 (http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL_web)
   Copyright Vernon Adams

* Slick, Copyright (c) Ken Wheeler, Licensed under MIT,  http://github.com/kenwheeler/slick/
* Magnific Popup -  Copyright (c) 2016 Dmitry Semenov Licensed under MIT, http://dimsemenov.com/plugins/magnific-popup/
* Theia Sticky Sidebar v1.7.0  MIT License (MIT) https://github.com/WeCodePixels/theia-sticky-sidebar
* normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal Licensed under MIT, https://necolas.github.io/normalize.css/

Webfont Loader:
Copyright: Copyright (c) 2020 WPTT
URL:  https://github.com/WPTT/webfont-loader
License: MIT License 

Images:

* Assets (SVG icons) inside /images theme folder
Copyright (C) 2019, unitedTheme and available as [GPLv3](https://www.gnu.org/licenses/gpl-3.0.html)

Images used from stocksnap.com
stocksnap provides images under CC0 license
(https://creativecommons.org/publicdomain/zero/1.0/)

https://stocksnap.io/photo/FBGHDTU974
https://stocksnap.io/photo/8SM5T92EN3
https://stocksnap.io/photo/Y6XSIB25MP
https://stocksnap.io/photo/OEQ3TT7IYF
https://stocksnap.io/photo/9YQLKH6FL5
https://stocksnap.io/photo/1I7Z2ITNT2


== Changelog ==

1.3.1 - July 14 2025
* Removed - Stumbleupon icon.
* Fixed - ARIA hidden element must not be focusable or contain focusable elements
* Fixed - Buttons must have discernible text

1.3.0 - June 01 2025
* Update - 6.8 compatibility
* Update: font for enhanced readability and modern aesthetics.

1.2.9 - March 28 2025
* Update - SVG social icons

1.2.8 - Feb 05 2025
* Update - Minor design issue

1.2.7 - Oct 03 2024
* Update - 6.6 compatibility

1.2.6 - July 05 2024
* Update - 6.5 compatibility
* Update - Minor design issue

1.2.5 - March 10 2024
* Update - Admin Dashboard

1.2.4 - Jan 12 2024
* Update - 404 Error Page
* Update - 6.4 compatibility
* New - Fixed Floating navigation

1.2.3 -Nov 09 2023
* Update - 6.3 compatibility
* Update - Discord Icon

1.2.2 - Oct 02 2023
* Update - wp_add_inline_style
* Update - Various Small fixes

1.2.0 - Aug 03 2023
* Update - Header meta viewport
* Update - Recent Widget
* Update - Single Related Post
* Update - Twitter Logo
* Update - Magnific Popup delegate

1.1.9 - June 02 2023
* Update - Various Small fixes

1.1.8 - May 12 2023
* Update - 6.2 compatibility
* Update - Various Small fixes

= 1.1.7 - March 22 2023 =
* Update - RTL support
* Fixed  - Various small fixes.

= 1.1.6 - Dec 25 2022 =
* Minor Design Adjustment
* RTL Issue on slick slide fixed

1.1.5 - Feb 18 2022
* Add about page and quick links

1.1.4 - Nov 16 2021
* Add custom Cursor

1.1.3 - Sep 13 2021
* Minor Design issue fixed
* WordPress supported version requirement check added

1.1.2 - Aug 08 2021
* Added Preloader function
* Fixed typo issue on script.js
* Some Design Adjustment

1.1.1 - June 16 2021
* Webfont loader added.

1.1.0 - March 11 2021
* Update Icons.

1.0.9 - February 10 2021
* Updated fixing skip link.

1.0.8 - Nov 04 2020
* updated fixing skip link
* updated fixing some css glitch

1.0.7 - Aug 04 2020
* updated fixing content issue

1.0.6 - Jul 31 2020
* updated fixing version and other some CSS glitches

1.0.4 - Mar 18 2020
* updated fixing keyboard navigation for pop up search

1.0.3 - Dec 20 2019
* updated fixing new version compatibility

1.0.2 - Nov 01 2019
* updated with language file compatibility

1.0.1 - Aug 19 2019
* Added Theia Sticky Sidebar
* Added the wp_body_open action.
* Added skip links TRT requirement.
* Managed RTL compatibility and added the rtl-language-support tag.

1.0.0 - Feb 12 2019
* Initial release