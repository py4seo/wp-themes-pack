
	<?php do_action('smartline_before_footer'); ?>

	<footer id="footer" class="clearfix" role="contentinfo">

		<?php // Display Footer Navigation
		if ( has_nav_menu( 'footer' ) ) : ?>

		<nav id="footernav" class="clearfix" role="navigation">
			<?php wp_nav_menu(	array(
				'theme_location' => 'footer',
				'container' => false,
				'menu_id' => 'footernav-menu',
				'fallback_cb' => '',
				'depth' => 1)
			);
			?>
		</nav>

		<?php endif; ?>

		<div id="footer-text">
            <p>Copyright &copy; 2016 - <?php echo date('Y'); ?> | <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>

		</div>

	</footer>

</div><!-- end #wrapper -->

<?php wp_footer(); ?>
</body>
</html>
