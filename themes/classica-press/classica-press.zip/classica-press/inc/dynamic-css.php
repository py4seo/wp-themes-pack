<?php

/**
 * Dynamic CSS
 */
function classica_press_dynamic_css() {

	$site_title_font       = get_theme_mod( 'classica_press_site_title_font', 'UnifrakturCook' );
	$site_description_font = get_theme_mod( 'classica_press_site_description_font', 'Libre Franklin' );
	$header_font           = get_theme_mod( 'classica_press_header_font', 'Newsreader' );
	$body_font             = get_theme_mod( 'classica_press_body_font', 'Libre Franklin' );
	$tagline_color         = get_theme_mod( 'classica_press_tagline_color', '#000000' );

	$custom_css  = '';
	$custom_css .= '
	/* Color */
	:root {
		--site-tagline-color: ' . esc_attr( $tagline_color ) . ';
		--site-title-color: ' . esc_attr( '#' . get_header_textcolor() ) . ';
	}
	';

	$custom_css .= '
	/* Typograhpy */
	:root {
		--font-heading: "' . esc_attr( $header_font ) . '", serif;
		--font-main: -apple-system, BlinkMacSystemFont,"' . esc_attr( $body_font ) . '", "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
	}

	body,
	button, input, select, optgroup, textarea {
		font-family: "' . esc_attr( $body_font ) . '", serif;
	}

	.site-title a {
		font-family: "' . esc_attr( $site_title_font ) . '", serif;
	}
	
	.site-description {
		font-family: "' . esc_attr( $site_description_font ) . '", serif;
	}
	';

	wp_add_inline_style( 'classica-press-style', $custom_css );

}

add_action( 'wp_enqueue_scripts', 'classica_press_dynamic_css', 99 );
