<?php
/**
 * Color Option
 *
 * @package Classica Press
 */

// Header Tagline Color.
$wp_customize->add_setting(
	'classica_press_tagline_color',
	array(
		'default'           => '#000000',
		'sanitize_callback' => 'sanitize_hex_color',
	)
);

$wp_customize->add_control(
	new WP_Customize_Color_Control(
		$wp_customize,
		'classica_press_tagline_color',
		array(
			'label'   => __( 'Tagline Color', 'classica-press' ),
			'section' => 'colors',
		)
	)
);
