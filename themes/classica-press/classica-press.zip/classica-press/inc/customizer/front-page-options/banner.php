<?php
/**
 * Banner Section
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_banner_section',
	array(
		'panel' => 'classica_press_front_page_options',
		'title' => esc_html__( 'Banner Section', 'classica-press' ),
	)
);

// Banner Section - Enable Section.
$wp_customize->add_setting(
	'classica_press_enable_banner_section',
	array(
		'default'           => false,
		'sanitize_callback' => 'classica_press_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Classica_Press_Toggle_Switch_Custom_Control(
		$wp_customize,
		'classica_press_enable_banner_section',
		array(
			'label'    => esc_html__( 'Enable Banner Section', 'classica-press' ),
			'section'  => 'classica_press_banner_section',
			'settings' => 'classica_press_enable_banner_section',
		)
	)
);

if ( isset( $wp_customize->selective_refresh ) ) {
	$wp_customize->selective_refresh->add_partial(
		'classica_press_enable_banner_section',
		array(
			'selector' => '#classica_press_banner_section .section-link',
			'settings' => 'classica_press_enable_banner_section',
		)
	);
}

// Banner Section - Top Stories Title.
$wp_customize->add_setting(
	'classica_press_top_stories_title',
	array(
		'default'           => __( 'Top Stories', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_top_stories_title',
	array(
		'label'           => esc_html__( 'Top Stories Title Label', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_top_stories_title',
		'type'            => 'text',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);

// Banner Section - Banner Slider Slider Content Type.
$wp_customize->add_setting(
	'classica_press_top_stories_content_type',
	array(
		'default'           => 'post',
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_top_stories_content_type',
	array(
		'label'           => esc_html__( 'Select Banner Content Type', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_top_stories_content_type',
		'type'            => 'select',
		'active_callback' => 'classica_press_is_banner_section_enabled',
		'choices'         => array(
			'post'     => esc_html__( 'Post', 'classica-press' ),
			'category' => esc_html__( 'Category', 'classica-press' ),
		),
	)
);

for ( $i = 1; $i <= 2; $i++ ) {
	// Banner Section - Select Top Stories Post.
	$wp_customize->add_setting(
		'classica_press_top_stories_content_post_' . $i,
		array(
			'sanitize_callback' => 'absint',
		)
	);

	$wp_customize->add_control(
		'classica_press_top_stories_content_post_' . $i,
		array(
			'label'           => sprintf( esc_html__( 'Select Post %d', 'classica-press' ), $i ),
			'section'         => 'classica_press_banner_section',
			'settings'        => 'classica_press_top_stories_content_post_' . $i,
			'active_callback' => 'classica_press_is_top_stories_section_and_content_type_post_enabled',
			'type'            => 'select',
			'choices'         => classica_press_get_post_choices(),
		)
	);
}

// Banner Section - Select Top Stories Category.
$wp_customize->add_setting(
	'classica_press_top_stories_content_category',
	array(
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_top_stories_content_category',
	array(
		'label'           => esc_html__( 'Select Category', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_top_stories_content_category',
		'active_callback' => 'classica_press_is_top_stories_section_and_content_type_category_enabled',
		'type'            => 'select',
		'choices'         => classica_press_get_post_cat_choices(),
	)
);

// Banner Section - Top Stories Button Label.
$wp_customize->add_setting(
	'classica_press_top_stories_button_label',
	array(
		'default'           => __( 'View All', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_top_stories_button_label',
	array(
		'label'           => esc_html__( 'Button Label', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_top_stories_button_label',
		'type'            => 'text',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);

// Banner Section - Top Stories Button Link.
$wp_customize->add_setting(
	'classica_press_top_stories_button_link',
	array(
		'sanitize_callback' => 'esc_url_raw',
	)
);

$wp_customize->add_control(
	'classica_press_top_stories_button_link',
	array(
		'label'           => esc_html__( 'Button Link', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_top_stories_button_link',
		'type'            => 'url',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);

// Banner Section - Horizontal Line.
$wp_customize->add_setting(
	'classica_press_top_stories_horizontal_line',
	array(
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new Classica_Press_Customize_Horizontal_Line(
		$wp_customize,
		'classica_press_top_stories_horizontal_line',
		array(
			'section'         => 'classica_press_banner_section',
			'settings'        => 'classica_press_top_stories_horizontal_line',
			'active_callback' => 'classica_press_is_banner_section_enabled',
			'type'            => 'hr',
		)
	)
);

// Banner Section - Main Banner Title.
$wp_customize->add_setting(
	'classica_press_main_banner_title',
	array(
		'default'           => __( 'Main Banner', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_main_banner_title',
	array(
		'label'           => esc_html__( 'Main Banner Title Label', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_main_banner_title',
		'type'            => 'text',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);

// Banner Section - Excerpt Length.
$wp_customize->add_setting(
	'classica_press_main_banner_excerpt_length',
	array(
		'default'           => 120,
		'sanitize_callback' => 'classica_press_sanitize_number_range',
	)
);

$wp_customize->add_control(
	'classica_press_main_banner_excerpt_length',
	array(
		'label'           => esc_html__( 'Excerpt Length (no. of words)', 'classica-press' ),
		'description'     => esc_html__( 'Note: Min 1. Please input the valid number and save. Then refresh the page to see the change.', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_main_banner_excerpt_length',
		'active_callback' => 'classica_press_is_banner_section_enabled',
		'type'            => 'number',
		'input_attrs'     => array(
			'min' => 1,
		),
	)
);

// Banner Section - Banner Slider Slider Content Type.
$wp_customize->add_setting(
	'classica_press_main_banner_content_type',
	array(
		'default'           => 'post',
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_main_banner_content_type',
	array(
		'label'           => esc_html__( 'Select Banner Content Type', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_main_banner_content_type',
		'type'            => 'select',
		'active_callback' => 'classica_press_is_banner_section_enabled',
		'choices'         => array(
			'post'     => esc_html__( 'Post', 'classica-press' ),
			'category' => esc_html__( 'Category', 'classica-press' ),
		),
	)
);

for ( $i = 1; $i <= 2; $i++ ) {
	// Banner Section - Select Banner Slider Post.
	$wp_customize->add_setting(
		'classica_press_main_banner_content_post_' . $i,
		array(
			'sanitize_callback' => 'absint',
		)
	);

	$wp_customize->add_control(
		'classica_press_main_banner_content_post_' . $i,
		array(
			'label'           => sprintf( esc_html__( 'Select Post %d', 'classica-press' ), $i ),
			'section'         => 'classica_press_banner_section',
			'settings'        => 'classica_press_main_banner_content_post_' . $i,
			'active_callback' => 'classica_press_is_main_banner_section_and_content_type_post_enabled',
			'type'            => 'select',
			'choices'         => classica_press_get_post_choices(),
		)
	);

}

// Banner Section - Select Banner Slider Category.
$wp_customize->add_setting(
	'classica_press_main_banner_content_category',
	array(
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_main_banner_content_category',
	array(
		'label'           => esc_html__( 'Select Category', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_main_banner_content_category',
		'active_callback' => 'classica_press_is_main_banner_section_and_content_type_category_enabled',
		'type'            => 'select',
		'choices'         => classica_press_get_post_cat_choices(),
	)
);

// Banner Section - Main Banner Button Label.
$wp_customize->add_setting(
	'classica_press_main_banner_button_label',
	array(
		'default'           => __( 'View All', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_main_banner_button_label',
	array(
		'label'           => esc_html__( 'Button Label', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_main_banner_button_label',
		'type'            => 'text',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);

// Banner Section - Main Banner Button Link.
$wp_customize->add_setting(
	'classica_press_main_banner_button_link',
	array(
		'sanitize_callback' => 'esc_url_raw',
	)
);

$wp_customize->add_control(
	'classica_press_main_banner_button_link',
	array(
		'label'           => esc_html__( 'Button Link', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_main_banner_button_link',
		'type'            => 'url',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);

// Banner Section - Horizontal Line.
$wp_customize->add_setting(
	'classica_press_main_banner_horizontal_line',
	array(
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new Classica_Press_Customize_Horizontal_Line(
		$wp_customize,
		'classica_press_main_banner_horizontal_line',
		array(
			'section'         => 'classica_press_banner_section',
			'settings'        => 'classica_press_main_banner_horizontal_line',
			'active_callback' => 'classica_press_is_banner_section_enabled',
			'type'            => 'hr',
		)
	)
);

// Banner Section - Editor Choice Title.
$wp_customize->add_setting(
	'classica_press_editor_choice_title',
	array(
		'default'           => __( 'Editor Choice', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_editor_choice_title',
	array(
		'label'           => esc_html__( 'Editor Choice Title Label', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_editor_choice_title',
		'type'            => 'text',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);

// Banner Section - Banner Slider Slider Content Type.
$wp_customize->add_setting(
	'classica_press_editor_choice_content_type',
	array(
		'default'           => 'post',
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_editor_choice_content_type',
	array(
		'label'           => esc_html__( 'Select Banner Content Type', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_editor_choice_content_type',
		'type'            => 'select',
		'active_callback' => 'classica_press_is_banner_section_enabled',
		'choices'         => array(
			'post'     => esc_html__( 'Post', 'classica-press' ),
			'category' => esc_html__( 'Category', 'classica-press' ),
		),
	)
);

for ( $i = 1; $i <= 3; $i++ ) {
	// Banner Section - Select Editor Choice Post.
	$wp_customize->add_setting(
		'classica_press_editor_choice_content_post_' . $i,
		array(
			'sanitize_callback' => 'absint',
		)
	);

	$wp_customize->add_control(
		'classica_press_editor_choice_content_post_' . $i,
		array(
			'label'           => sprintf( esc_html__( 'Select Post %d', 'classica-press' ), $i ),
			'section'         => 'classica_press_banner_section',
			'settings'        => 'classica_press_editor_choice_content_post_' . $i,
			'active_callback' => 'classica_press_is_editor_choice_section_and_content_type_post_enabled',
			'type'            => 'select',
			'choices'         => classica_press_get_post_choices(),
		)
	);

}

// Banner Section - Select Editor Choice Category.
$wp_customize->add_setting(
	'classica_press_editor_choice_content_category',
	array(
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_editor_choice_content_category',
	array(
		'label'           => esc_html__( 'Select Category', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_editor_choice_content_category',
		'active_callback' => 'classica_press_is_editor_choice_section_and_content_type_category_enabled',
		'type'            => 'select',
		'choices'         => classica_press_get_post_cat_choices(),
	)
);

// Banner Section - Editor Choice Button Label.
$wp_customize->add_setting(
	'classica_press_editor_choice_button_label',
	array(
		'default'           => __( 'View All', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_editor_choice_button_label',
	array(
		'label'           => esc_html__( 'Button Label', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_editor_choice_button_label',
		'type'            => 'text',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);

// Banner Section - Editor Choice Button Link.
$wp_customize->add_setting(
	'classica_press_editor_choice_button_link',
	array(
		'sanitize_callback' => 'esc_url_raw',
	)
);

$wp_customize->add_control(
	'classica_press_editor_choice_button_link',
	array(
		'label'           => esc_html__( 'Button Link', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_editor_choice_button_link',
		'type'            => 'url',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);

// Banner Section - Horizontal Line.
$wp_customize->add_setting(
	'classica_press_editor_choice_horizontal_line',
	array(
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	new Classica_Press_Customize_Horizontal_Line(
		$wp_customize,
		'classica_press_editor_choice_horizontal_line',
		array(
			'section'         => 'classica_press_banner_section',
			'settings'        => 'classica_press_editor_choice_horizontal_line',
			'active_callback' => 'classica_press_is_banner_section_enabled',
			'type'            => 'hr',
		)
	)
);

// Banner Section - Advertisement Image.
$wp_customize->add_setting(
	'classica_press_advertisement_image',
	array(
		'sanitize_callback' => 'classica_press_sanitize_image',
	)
);

$wp_customize->add_control(
	new WP_Customize_Image_Control(
		$wp_customize,
		'classica_press_advertisement_image',
		array(
			'label'           => esc_html__( 'Advertisement', 'classica-press' ),
			'section'         => 'classica_press_banner_section',
			'settings'        => 'classica_press_advertisement_image',
			'active_callback' => 'classica_press_is_banner_section_enabled',
		)
	)
);

// Banner Section - Advertisement Image URL.
$wp_customize->add_setting(
	'classica_press_advertisement_image_url',
	array(
		'default'           => '',
		'sanitize_callback' => 'esc_url_raw',
	)
);

$wp_customize->add_control(
	'classica_press_advertisement_image_url',
	array(
		'label'           => esc_html__( 'Advertisement URL', 'classica-press' ),
		'section'         => 'classica_press_banner_section',
		'settings'        => 'classica_press_advertisement_image_url',
		'type'            => 'url',
		'active_callback' => 'classica_press_is_banner_section_enabled',
	)
);
