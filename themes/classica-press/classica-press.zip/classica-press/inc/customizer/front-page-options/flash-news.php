<?php
/**
 * Flash News Section
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_flash_news_section',
	array(
		'panel' => 'classica_press_front_page_options',
		'title' => esc_html__( 'Flash News Section', 'classica-press' ),
	)
);

// Flash News Section - Enable Section.
$wp_customize->add_setting(
	'classica_press_enable_flash_news_section',
	array(
		'default'           => false,
		'sanitize_callback' => 'classica_press_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Classica_Press_Toggle_Switch_Custom_Control(
		$wp_customize,
		'classica_press_enable_flash_news_section',
		array(
			'label'    => esc_html__( 'Enable Flash News Section', 'classica-press' ),
			'section'  => 'classica_press_flash_news_section',
			'settings' => 'classica_press_enable_flash_news_section',
		)
	)
);

if ( isset( $wp_customize->selective_refresh ) ) {
	$wp_customize->selective_refresh->add_partial(
		'classica_press_enable_flash_news_section',
		array(
			'selector' => '#classica_press_flash_news_section .section-link',
			'settings' => 'classica_press_enable_flash_news_section',
		)
	);
}

// Flash News Section - Section Title.
$wp_customize->add_setting(
	'classica_press_flash_news_title',
	array(
		'default'           => __( 'Flash News', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_flash_news_title',
	array(
		'label'           => esc_html__( 'Section Title', 'classica-press' ),
		'section'         => 'classica_press_flash_news_section',
		'settings'        => 'classica_press_flash_news_title',
		'type'            => 'text',
		'active_callback' => 'classica_press_is_flash_news_section_enabled',
	)
);

// Flash News Section - Speed Controller.
$wp_customize->add_setting(
	'classica_press_flash_news_speed_controller',
	array(
		'default'           => 30,
		'sanitize_callback' => 'classica_press_sanitize_number_range',
	)
);

$wp_customize->add_control(
	'classica_press_flash_news_speed_controller',
	array(
		'label'           => esc_html__( 'Speed Controller', 'classica-press' ),
		'description'     => esc_html__( 'Note: Default speed value is 30.', 'classica-press' ),
		'section'         => 'classica_press_flash_news_section',
		'settings'        => 'classica_press_flash_news_speed_controller',
		'type'            => 'number',
		'input_attrs'     => array(
			'min' => 1,
		),
		'active_callback' => 'classica_press_is_flash_news_section_enabled',
	)
);

// Flash News Section - Content Type.
$wp_customize->add_setting(
	'classica_press_flash_news_content_type',
	array(
		'default'           => 'post',
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_flash_news_content_type',
	array(
		'label'           => esc_html__( 'Select Content Type', 'classica-press' ),
		'section'         => 'classica_press_flash_news_section',
		'settings'        => 'classica_press_flash_news_content_type',
		'type'            => 'select',
		'active_callback' => 'classica_press_is_flash_news_section_enabled',
		'choices'         => array(
			'post'     => esc_html__( 'Post', 'classica-press' ),
			'category' => esc_html__( 'Category', 'classica-press' ),
		),
	)
);

for ( $i = 1; $i <= 6; $i++ ) {
	// Flash News Section - Select Post.
	$wp_customize->add_setting(
		'classica_press_flash_news_content_post_' . $i,
		array(
			'sanitize_callback' => 'absint',
		)
	);

	$wp_customize->add_control(
		'classica_press_flash_news_content_post_' . $i,
		array(
			'label'           => sprintf( esc_html__( 'Select Post %d', 'classica-press' ), $i ),
			'section'         => 'classica_press_flash_news_section',
			'settings'        => 'classica_press_flash_news_content_post_' . $i,
			'active_callback' => 'classica_press_is_flash_news_section_and_content_type_post_enabled',
			'type'            => 'select',
			'choices'         => classica_press_get_post_choices(),
		)
	);

}

// Flash News Section - Select Category.
$wp_customize->add_setting(
	'classica_press_flash_news_content_category',
	array(
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_flash_news_content_category',
	array(
		'label'           => esc_html__( 'Select Category', 'classica-press' ),
		'section'         => 'classica_press_flash_news_section',
		'settings'        => 'classica_press_flash_news_content_category',
		'active_callback' => 'classica_press_is_flash_news_section_and_content_type_category_enabled',
		'type'            => 'select',
		'choices'         => classica_press_get_post_cat_choices(),
	)
);
