<?php
/**
 * Grid Section
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_grid_section',
	array(
		'panel' => 'classica_press_front_page_options',
		'title' => esc_html__( 'Posts Grid Section', 'classica-press' ),
	)
);

// Grid Section - Enable Section.
$wp_customize->add_setting(
	'classica_press_enable_grid_section',
	array(
		'default'           => false,
		'sanitize_callback' => 'classica_press_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Classica_Press_Toggle_Switch_Custom_Control(
		$wp_customize,
		'classica_press_enable_grid_section',
		array(
			'label'    => esc_html__( 'Enable Grid Section', 'classica-press' ),
			'section'  => 'classica_press_grid_section',
			'settings' => 'classica_press_enable_grid_section',
		)
	)
);

if ( isset( $wp_customize->selective_refresh ) ) {
	$wp_customize->selective_refresh->add_partial(
		'classica_press_enable_grid_section',
		array(
			'selector' => '#classica_press_grid_section .section-link',
			'settings' => 'classica_press_enable_grid_section',
		)
	);
}

// Grid Section - Section Title.
$wp_customize->add_setting(
	'classica_press_grid_title',
	array(
		'default'           => __( 'Grid Posts', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_grid_title',
	array(
		'label'           => esc_html__( 'Section Title', 'classica-press' ),
		'section'         => 'classica_press_grid_section',
		'settings'        => 'classica_press_grid_title',
		'type'            => 'text',
		'active_callback' => 'classica_press_is_grid_section_enabled',
	)
);

// Grid Section - Grid Content Type.
$wp_customize->add_setting(
	'classica_press_grid_content_type',
	array(
		'default'           => 'post',
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_grid_content_type',
	array(
		'label'           => esc_html__( 'Select Content Type', 'classica-press' ),
		'section'         => 'classica_press_grid_section',
		'settings'        => 'classica_press_grid_content_type',
		'type'            => 'select',
		'active_callback' => 'classica_press_is_grid_section_enabled',
		'choices'         => array(
			'post'     => esc_html__( 'Post', 'classica-press' ),
			'category' => esc_html__( 'Category', 'classica-press' ),
		),
	)
);

// Grid Section - Select grid Category.
$wp_customize->add_setting(
	'classica_press_grid_content_category',
	array(
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_grid_content_category',
	array(
		'label'           => esc_html__( 'Select Category', 'classica-press' ),
		'section'         => 'classica_press_grid_section',
		'settings'        => 'classica_press_grid_content_category',
		'active_callback' => 'classica_press_is_grid_section_and_content_type_category_enabled',
		'type'            => 'select',
		'choices'         => classica_press_get_post_cat_choices(),
	)
);

for ( $i = 1; $i <= 4; $i++ ) {

	// Grid Section - Select grid Post.
	$wp_customize->add_setting(
		'classica_press_grid_content_post_' . $i,
		array(
			'sanitize_callback' => 'absint',
		)
	);

	$wp_customize->add_control(
		'classica_press_grid_content_post_' . $i,
		array(
			'label'           => sprintf( esc_html__( 'Select Post %d', 'classica-press' ), $i ),
			'section'         => 'classica_press_grid_section',
			'settings'        => 'classica_press_grid_content_post_' . $i,
			'active_callback' => 'classica_press_is_grid_section_and_content_type_post_enabled',
			'type'            => 'select',
			'choices'         => classica_press_get_post_choices(),
		)
	);

}

// Grid Section - Button Label.
$wp_customize->add_setting(
	'classica_press_grid_button_label',
	array(
		'default'           => __( 'View All', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_grid_button_label',
	array(
		'label'           => esc_html__( 'Button Label', 'classica-press' ),
		'section'         => 'classica_press_grid_section',
		'settings'        => 'classica_press_grid_button_label',
		'type'            => 'text',
		'active_callback' => 'classica_press_is_grid_section_enabled',
	)
);

// Grid Section - Button Link.
$wp_customize->add_setting(
	'classica_press_grid_button_link',
	array(
		'default'           => '#',
		'sanitize_callback' => 'esc_url_raw',
	)
);

$wp_customize->add_control(
	'classica_press_grid_button_link',
	array(
		'label'           => esc_html__( 'Button Link', 'classica-press' ),
		'section'         => 'classica_press_grid_section',
		'settings'        => 'classica_press_grid_button_link',
		'type'            => 'url',
		'active_callback' => 'classica_press_is_grid_section_enabled',
	)
);
