<?php
/**
 * Archive Layout
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_archive_layout',
	array(
		'title' => esc_html__( 'Archive Layout', 'classica-press' ),
		'panel' => 'classica_press_theme_options',
	)
);

// Archive Layout - Column Layout.
$wp_customize->add_setting(
	'classica_press_archive_column_layout',
	array(
		'default'           => 'column-2',
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_archive_column_layout',
	array(
		'label'   => esc_html__( 'Column Layout', 'classica-press' ),
		'section' => 'classica_press_archive_layout',
		'type'    => 'select',
		'choices' => array(
			'column-2' => __( 'Column 2', 'classica-press' ),
			'column-3' => __( 'Column 3', 'classica-press' ),
		),
	)
);
