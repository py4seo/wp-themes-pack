<?php
/**
 * Breadcrumb
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_breadcrumb',
	array(
		'title' => esc_html__( 'Breadcrumb', 'classica-press' ),
		'panel' => 'classica_press_theme_options',
	)
);

// Breadcrumb - Enable Breadcrumb.
$wp_customize->add_setting(
	'classica_press_enable_breadcrumb',
	array(
		'sanitize_callback' => 'classica_press_sanitize_switch',
		'default'           => true,
	)
);

$wp_customize->add_control(
	new Classica_Press_Toggle_Switch_Custom_Control(
		$wp_customize,
		'classica_press_enable_breadcrumb',
		array(
			'label'   => esc_html__( 'Enable Breadcrumb', 'classica-press' ),
			'section' => 'classica_press_breadcrumb',
		)
	)
);

// Breadcrumb - Separator.
$wp_customize->add_setting(
	'classica_press_breadcrumb_separator',
	array(
		'sanitize_callback' => 'sanitize_text_field',
		'default'           => '/',
	)
);

$wp_customize->add_control(
	'classica_press_breadcrumb_separator',
	array(
		'label'           => esc_html__( 'Separator', 'classica-press' ),
		'active_callback' => 'classica_press_is_breadcrumb_enabled',
		'section'         => 'classica_press_breadcrumb',
	)
);
