<?php
/**
 * Typography
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_typography',
	array(
		'panel' => 'classica_press_theme_options',
		'title' => esc_html__( 'Typography', 'classica-press' ),
	)
);

// Typography - Site Title Font.
$wp_customize->add_setting(
	'classica_press_site_title_font',
	array(
		'default'           => 'UnifrakturCook',
		'sanitize_callback' => 'classica_press_sanitize_google_fonts',
	)
);

$wp_customize->add_control(
	'classica_press_site_title_font',
	array(
		'label'    => esc_html__( 'Site Title Font Family', 'classica-press' ),
		'section'  => 'classica_press_typography',
		'settings' => 'classica_press_site_title_font',
		'type'     => 'select',
		'choices'  => classica_press_get_all_google_font_families(),
	)
);

// Typography - Site Description Font.
$wp_customize->add_setting(
	'classica_press_site_description_font',
	array(
		'default'           => 'Libre Franklin',
		'sanitize_callback' => 'classica_press_sanitize_google_fonts',
	)
);

$wp_customize->add_control(
	'classica_press_site_description_font',
	array(
		'label'    => esc_html__( 'Site Description Font Family', 'classica-press' ),
		'section'  => 'classica_press_typography',
		'settings' => 'classica_press_site_description_font',
		'type'     => 'select',
		'choices'  => classica_press_get_all_google_font_families(),
	)
);

// Typography - Header Font.
$wp_customize->add_setting(
	'classica_press_header_font',
	array(
		'default'           => 'Newsreader',
		'sanitize_callback' => 'classica_press_sanitize_google_fonts',
	)
);

$wp_customize->add_control(
	'classica_press_header_font',
	array(
		'label'    => esc_html__( 'Header Font Family', 'classica-press' ),
		'section'  => 'classica_press_typography',
		'settings' => 'classica_press_header_font',
		'type'     => 'select',
		'choices'  => classica_press_get_all_google_font_families(),
	)
);

// Typography - Body Font.
$wp_customize->add_setting(
	'classica_press_body_font',
	array(
		'default'           => 'Libre Franklin',
		'sanitize_callback' => 'classica_press_sanitize_google_fonts',
	)
);

$wp_customize->add_control(
	'classica_press_body_font',
	array(
		'label'    => esc_html__( 'Body Font Family', 'classica-press' ),
		'section'  => 'classica_press_typography',
		'settings' => 'classica_press_body_font',
		'type'     => 'select',
		'choices'  => classica_press_get_all_google_font_families(),
	)
);
