<?php
/**
 * Sidebar Option
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_sidebar_option',
	array(
		'title' => esc_html__( 'Layout', 'classica-press' ),
		'panel' => 'classica_press_theme_options',
	)
);

// Sidebar Option - Global Sidebar Position.
$wp_customize->add_setting(
	'classica_press_sidebar_position',
	array(
		'sanitize_callback' => 'classica_press_sanitize_select',
		'default'           => 'right-sidebar',
	)
);

$wp_customize->add_control(
	'classica_press_sidebar_position',
	array(
		'label'   => esc_html__( 'Global Sidebar Position', 'classica-press' ),
		'section' => 'classica_press_sidebar_option',
		'type'    => 'select',
		'choices' => array(
			'right-sidebar' => esc_html__( 'Right Sidebar', 'classica-press' ),
			'no-sidebar'    => esc_html__( 'No Sidebar', 'classica-press' ),
		),
	)
);

// Sidebar Option - Post Sidebar Position.
$wp_customize->add_setting(
	'classica_press_post_sidebar_position',
	array(
		'sanitize_callback' => 'classica_press_sanitize_select',
		'default'           => 'right-sidebar',
	)
);

$wp_customize->add_control(
	'classica_press_post_sidebar_position',
	array(
		'label'   => esc_html__( 'Post Sidebar Position', 'classica-press' ),
		'section' => 'classica_press_sidebar_option',
		'type'    => 'select',
		'choices' => array(
			'right-sidebar' => esc_html__( 'Right Sidebar', 'classica-press' ),
			'no-sidebar'    => esc_html__( 'No Sidebar', 'classica-press' ),
		),
	)
);

// Sidebar Option - Page Sidebar Position.
$wp_customize->add_setting(
	'classica_press_page_sidebar_position',
	array(
		'sanitize_callback' => 'classica_press_sanitize_select',
		'default'           => 'right-sidebar',
	)
);

$wp_customize->add_control(
	'classica_press_page_sidebar_position',
	array(
		'label'   => esc_html__( 'Page Sidebar Position', 'classica-press' ),
		'section' => 'classica_press_sidebar_option',
		'type'    => 'select',
		'choices' => array(
			'right-sidebar' => esc_html__( 'Right Sidebar', 'classica-press' ),
			'no-sidebar'    => esc_html__( 'No Sidebar', 'classica-press' ),
		),
	)
);
