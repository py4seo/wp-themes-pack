<?php
/**
 * Footer Options
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_footer_options',
	array(
		'panel' => 'classica_press_theme_options',
		'title' => esc_html__( 'Footer Options', 'classica-press' ),
	)
);

// Footer Options - Copyright Text.
/* translators: 1: Year, 2: Site Title with home URL. */
$copyright_default = sprintf( esc_html_x( 'Copyright &copy; %1$s %2$s', '1: Year, 2: Site Title with home URL', 'classica-press' ), '[the-year]', '[site-link]' );
$wp_customize->add_setting(
	'classica_press_footer_copyright_text',
	array(
		'default'           => $copyright_default,
		'sanitize_callback' => 'wp_kses_post',
	)
);

$wp_customize->add_control(
	'classica_press_footer_copyright_text',
	array(
		'label'    => esc_html__( 'Copyright Text', 'classica-press' ),
		'section'  => 'classica_press_footer_options',
		'settings' => 'classica_press_footer_copyright_text',
		'type'     => 'textarea',
	)
);
