<?php
/**
 * Excerpt
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_excerpt_options',
	array(
		'panel' => 'classica_press_theme_options',
		'title' => esc_html__( 'Excerpt', 'classica-press' ),
	)
);

// Excerpt - Excerpt Length.
$wp_customize->add_setting(
	'classica_press_excerpt_length',
	array(
		'default'           => 20,
		'sanitize_callback' => 'classica_press_sanitize_number_range',
		'validate_callback' => 'classica_press_validate_excerpt_length',
	)
);

$wp_customize->add_control(
	'classica_press_excerpt_length',
	array(
		'label'       => esc_html__( 'Excerpt Length (no. of words)', 'classica-press' ),
		'description' => esc_html__( 'Note: Min 1 & Max 100. Please input the valid number and save. Then refresh the page to see the change.', 'classica-press' ),
		'section'     => 'classica_press_excerpt_options',
		'settings'    => 'classica_press_excerpt_length',
		'type'        => 'number',
		'input_attrs' => array(
			'min'  => 1,
			'max'  => 100,
			'step' => 1,
		),
	)
);
