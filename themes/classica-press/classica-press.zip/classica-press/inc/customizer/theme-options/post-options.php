<?php
/**
 * Post Options
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_post_options',
	array(
		'title' => esc_html__( 'Post Options', 'classica-press' ),
		'panel' => 'classica_press_theme_options',
	)
);

// Post Options - Hide Date.
$wp_customize->add_setting(
	'classica_press_post_hide_date',
	array(
		'default'           => false,
		'sanitize_callback' => 'classica_press_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Classica_Press_Toggle_Switch_Custom_Control(
		$wp_customize,
		'classica_press_post_hide_date',
		array(
			'label'   => esc_html__( 'Hide Date', 'classica-press' ),
			'section' => 'classica_press_post_options',
		)
	)
);

// Post Options - Hide Author.
$wp_customize->add_setting(
	'classica_press_post_hide_author',
	array(
		'default'           => false,
		'sanitize_callback' => 'classica_press_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Classica_Press_Toggle_Switch_Custom_Control(
		$wp_customize,
		'classica_press_post_hide_author',
		array(
			'label'   => esc_html__( 'Hide Author', 'classica-press' ),
			'section' => 'classica_press_post_options',
		)
	)
);

// Post Options - Hide Category.
$wp_customize->add_setting(
	'classica_press_post_hide_category',
	array(
		'default'           => false,
		'sanitize_callback' => 'classica_press_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Classica_Press_Toggle_Switch_Custom_Control(
		$wp_customize,
		'classica_press_post_hide_category',
		array(
			'label'   => esc_html__( 'Hide Category', 'classica-press' ),
			'section' => 'classica_press_post_options',
		)
	)
);

// Post Options - Hide Tag.
$wp_customize->add_setting(
	'classica_press_post_hide_tags',
	array(
		'default'           => false,
		'sanitize_callback' => 'classica_press_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Classica_Press_Toggle_Switch_Custom_Control(
		$wp_customize,
		'classica_press_post_hide_tags',
		array(
			'label'   => esc_html__( 'Hide Tag', 'classica-press' ),
			'section' => 'classica_press_post_options',
		)
	)
);

// Post Options - Related Post Label.
$wp_customize->add_setting(
	'classica_press_post_related_post_label',
	array(
		'default'           => __( 'Related Posts', 'classica-press' ),
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'classica_press_post_related_post_label',
	array(
		'label'    => esc_html__( 'Related Posts Label', 'classica-press' ),
		'section'  => 'classica_press_post_options',
		'settings' => 'classica_press_post_related_post_label',
		'type'     => 'text',
	)
);
