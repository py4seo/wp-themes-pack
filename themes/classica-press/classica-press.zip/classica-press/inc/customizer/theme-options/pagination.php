<?php
/**
 * Pagination
 *
 * @package Classica Press
 */

$wp_customize->add_section(
	'classica_press_pagination',
	array(
		'panel' => 'classica_press_theme_options',
		'title' => esc_html__( 'Pagination', 'classica-press' ),
	)
);

// Pagination - Enable Pagination.
$wp_customize->add_setting(
	'classica_press_enable_pagination',
	array(
		'default'           => true,
		'sanitize_callback' => 'classica_press_sanitize_switch',
	)
);

$wp_customize->add_control(
	new Classica_Press_Toggle_Switch_Custom_Control(
		$wp_customize,
		'classica_press_enable_pagination',
		array(
			'label'    => esc_html__( 'Enable Pagination', 'classica-press' ),
			'section'  => 'classica_press_pagination',
			'settings' => 'classica_press_enable_pagination',
			'type'     => 'checkbox',
		)
	)
);

// Pagination - Pagination Type.
$wp_customize->add_setting(
	'classica_press_pagination_type',
	array(
		'default'           => 'numeric',
		'sanitize_callback' => 'classica_press_sanitize_select',
	)
);

$wp_customize->add_control(
	'classica_press_pagination_type',
	array(
		'label'           => esc_html__( 'Pagination Type', 'classica-press' ),
		'section'         => 'classica_press_pagination',
		'settings'        => 'classica_press_pagination_type',
		'active_callback' => 'classica_press_is_pagination_enabled',
		'type'            => 'select',
		'choices'         => array(
			'default' => __( 'Default (Older/Newer)', 'classica-press' ),
			'numeric' => __( 'Numeric', 'classica-press' ),
		),
	)
);
