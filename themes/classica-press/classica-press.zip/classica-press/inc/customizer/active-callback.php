<?php

/**
 * Active Callbacks
 *
 * @package Classica Press
 */

// Theme Options.
function classica_press_is_pagination_enabled( $control ) {
	return ( $control->manager->get_setting( 'classica_press_enable_pagination' )->value() );
}
function classica_press_is_breadcrumb_enabled( $control ) {
	return ( $control->manager->get_setting( 'classica_press_enable_breadcrumb' )->value() );
}

// Flash News Section.
function classica_press_is_flash_news_section_enabled( $control ) {
	return ( $control->manager->get_setting( 'classica_press_enable_flash_news_section' )->value() );
}
function classica_press_is_flash_news_section_and_content_type_post_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_flash_news_content_type' )->value();
	return ( classica_press_is_flash_news_section_enabled( $control ) && ( 'post' === $content_type ) );
}
function classica_press_is_flash_news_section_and_content_type_category_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_flash_news_content_type' )->value();
	return ( classica_press_is_flash_news_section_enabled( $control ) && ( 'category' === $content_type ) );
}

// Banner Section.
function classica_press_is_banner_section_enabled( $control ) {
	return ( $control->manager->get_setting( 'classica_press_enable_banner_section' )->value() );
}

// Banner Section - Main Banner.
function classica_press_is_main_banner_section_and_content_type_post_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_main_banner_content_type' )->value();
	return ( classica_press_is_banner_section_enabled( $control ) && ( 'post' === $content_type ) );
}
function classica_press_is_main_banner_section_and_content_type_category_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_main_banner_content_type' )->value();
	return ( classica_press_is_banner_section_enabled( $control ) && ( 'category' === $content_type ) );
}

// Banner Section - Top Stories.
function classica_press_is_top_stories_section_and_content_type_post_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_top_stories_content_type' )->value();
	return ( classica_press_is_banner_section_enabled( $control ) && ( 'post' === $content_type ) );
}
function classica_press_is_top_stories_section_and_content_type_category_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_top_stories_content_type' )->value();
	return ( classica_press_is_banner_section_enabled( $control ) && ( 'category' === $content_type ) );
}
// Banner Section - Editor Choice.
function classica_press_is_editor_choice_section_and_content_type_post_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_editor_choice_content_type' )->value();
	return ( classica_press_is_banner_section_enabled( $control ) && ( 'post' === $content_type ) );
}
function classica_press_is_editor_choice_section_and_content_type_category_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_editor_choice_content_type' )->value();
	return ( classica_press_is_banner_section_enabled( $control ) && ( 'category' === $content_type ) );
}

// Grid Section.
function classica_press_is_grid_section_enabled( $control ) {
	return ( $control->manager->get_setting( 'classica_press_enable_grid_section' )->value() );
}
function classica_press_is_grid_section_and_content_type_post_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_grid_content_type' )->value();
	return ( classica_press_is_grid_section_enabled( $control ) && ( 'post' === $content_type ) );
}
function classica_press_is_grid_section_and_content_type_category_enabled( $control ) {
	$content_type = $control->manager->get_setting( 'classica_press_grid_content_type' )->value();
	return ( classica_press_is_grid_section_enabled( $control ) && ( 'category' === $content_type ) );
}

// Check if static home page is enabled.
function classica_press_is_static_homepage_enabled( $control ) {
	return ( 'page' === $control->manager->get_setting( 'show_on_front' )->value() );
}
