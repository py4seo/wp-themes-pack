<?php
/**
 * Front Page Options
 *
 * @package Classica Press
 */

$wp_customize->add_panel(
	'classica_press_front_page_options',
	array(
		'title'    => esc_html__( 'Front Page Options', 'classica-press' ),
		'priority' => 130,
	)
);

// Flash News Section.
require get_template_directory() . '/inc/customizer/front-page-options/flash-news.php';

// Banner Section.
require get_template_directory() . '/inc/customizer/front-page-options/banner.php';

// Grid Section.
require get_template_directory() . '/inc/customizer/front-page-options/grid.php';
