<?php
$banner_title        = get_theme_mod( 'classica_press_main_banner_title', __( 'Main Banner', 'classica-press' ) );
$banner_button       = get_theme_mod( 'classica_press_main_banner_button_label', __( 'View All', 'classica-press' ) );
$banner_button_url   = get_theme_mod( 'classica_press_main_banner_button_link' );
$banner_content_type = get_theme_mod( 'classica_press_main_banner_content_type', 'post' );
if ( 'category' === $banner_content_type ) {
	$banner_category   = get_theme_mod( 'classica_press_main_banner_content_category' );
	$banner_button_url = ! empty( $banner_button_url ) ? $banner_button_url : get_category_link( $banner_category );
} else {
	$banner_button_url = ! empty( $banner_button_url ) ? $banner_button_url : '#';
}
?>
<div class="banner-main-part">
	<?php if ( ! empty( $banner_title || $banner_button ) ) { ?>
		<div class="title-heading">
			<h3 class="section-title">
				<?php echo esc_html( $banner_title ); ?>
			</h3>
			<?php if ( ! empty( $banner_button ) ) { ?>
				<a href="<?php echo esc_url( $banner_button_url ); ?>" class="view-all"><?php echo esc_html( $banner_button ); ?></a>
			<?php } ?>
		</div>
	<?php } ?>
	<div class="banner-headline-wrap banner-main-carousel slick-button">
		<?php
		$banner_query = new WP_Query( $main_banner_args );
		if ( $banner_query->have_posts() ) {
			while ( $banner_query->have_posts() ) :
				$banner_query->the_post();
				$excerpt_length = get_theme_mod( 'classica_press_main_banner_excerpt_length', 120 );

				?>
				<div class="blog-post-container grid-layout">
					<div class="blog-post-inner">
						<?php if ( has_post_thumbnail() ) { ?>
							<div class="blog-post-image">
								<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'post-thumbnail' ); ?></a>
							</div>
						<?php } ?>
						<div class="blog-post-detail">
							<div class="post-categories">
								<?php classica_press_categories_list(); ?>
							</div>
							<h2 class="entry-title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>
							<div class="post-meta">
								<?php classica_press_posted_by(); ?>
								<?php classica_press_posted_on(); ?>
							</div>
							<p class="post-excerpt">
								<?php echo wp_kses_post( wp_trim_words( get_the_content(), $excerpt_length ) ); ?>
							</p>
						</div>
					</div>
				</div>
				<?php
			endwhile;
			wp_reset_postdata();
		}
		?>
	</div>

</div>
