<div class="adver-grid">
	<?php
	$ads_image     = get_theme_mod( 'classica_press_advertisement_image' );
	$ads_image_url = get_theme_mod( 'classica_press_advertisement_image_url' );
	if ( ! empty( $ads_image ) ) :
		?>
		<a href="<?php echo esc_url( $ads_image_url ); ?>"><img src="<?php echo esc_url( $ads_image ); ?>" alt="<?php esc_attr_e( 'Advertisment Image', 'classica-press' ); ?>"></a>
		<?php
	endif;
	?>
</div>
