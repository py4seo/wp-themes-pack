<?php
$editor_title        = get_theme_mod( 'classica_press_editor_choice_title', __( 'Editor Choice', 'classica-press' ) );
$editor_button       = get_theme_mod( 'classica_press_editor_choice_button_label', __( 'View All', 'classica-press' ) );
$editor_button_url   = get_theme_mod( 'classica_press_editor_choice_button_link' );
$editor_content_type = get_theme_mod( 'classica_press_editor_choice_content_type', 'post' );
if ( 'category' === $editor_content_type ) {
	$editor_category   = get_theme_mod( 'classica_press_editor_choice_content_category' );
	$editor_button_url = ! empty( $editor_button_url ) ? $editor_button_url : get_category_link( $editor_category );
} else {
	$editor_button_url = ! empty( $editor_button_url ) ? $editor_button_url : '#';
}
?>
<div class="editors-choice">
	<?php if ( ! empty( $editor_title || $editor_button ) ) { ?>
		<div class="title-heading">
			<h3 class="section-title">
				<?php echo esc_html( $editor_title ); ?>
			</h3>
			<?php if ( ! empty( $editor_button ) ) { ?>
				<a href="<?php echo esc_url( $editor_button_url ); ?>" class="view-all"><?php echo esc_html( $editor_button ); ?></a>
			<?php } ?>
		</div>
	<?php } ?>
	<div class="editors-choice-wrap">
		<?php
		$editor_query = new WP_Query( $editor_args );
		if ( $editor_query->have_posts() ) {
			while ( $editor_query->have_posts() ) :
				$editor_query->the_post();
				?>
				<div class="blog-post-container list-layout">
					<div class="blog-post-inner">
						<?php if ( has_post_thumbnail() ) { ?>
							<div class="blog-post-image">
								<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'post-thumbnail' ); ?></a>
							</div>
						<?php } ?>
						<div class="blog-post-detail">
							<h2 class="entry-title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>
							<p class="post-excerpt">
								<?php echo wp_kses_post( wp_trim_words( get_the_content(), 20 ) ); ?>
							</p>
						</div>
					</div>
				</div>
				<?php
			endwhile;
			wp_reset_postdata();
		}
		?>
	</div>
	<?php require get_template_directory() . '/template-parts/sections/banner/advertisement.php'; ?>
</div>
