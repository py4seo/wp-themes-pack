<?php
$top_stories_title        = get_theme_mod( 'classica_press_top_stories_title', __( 'Top Stories', 'classica-press' ) );
$top_stories_button       = get_theme_mod( 'classica_press_top_stories_button_label', __( 'View All', 'classica-press' ) );
$top_stories_button_url   = get_theme_mod( 'classica_press_top_stories_button_link' );
$top_stories_content_type = get_theme_mod( 'classica_press_top_stories_content_type', 'post' );
if ( 'category' === $top_stories_content_type ) {
	$top_stories_category   = get_theme_mod( 'classica_press_top_stories_content_category' );
	$top_stories_button_url = ! empty( $top_stories_button_url ) ? $top_stories_button_url : get_category_link( $top_stories_category );
} else {
	$top_stories_button_url = ! empty( $top_stories_button_url ) ? $top_stories_button_url : '#';
}
?>
<div class="top-stories">
	<?php if ( ! empty( $top_stories_title || $top_stories_button ) ) { ?>
		<div class="title-heading">
			<h3 class="section-title">
				<?php echo esc_html( $top_stories_title ); ?>
			</h3>
			<?php if ( ! empty( $top_stories_button ) ) { ?>
				<a href="<?php echo esc_url( $top_stories_button_url ); ?>" class="view-all"><?php echo esc_html( $top_stories_button ); ?></a>
			<?php } ?>
		</div>
	<?php } ?>
	<div class="top-stories-wrap">
		<?php
		$top_stories_query = new WP_Query( $stories_args );
		if ( $top_stories_query->have_posts() ) {
			while ( $top_stories_query->have_posts() ) :
				$top_stories_query->the_post();
				?>
				<div class="blog-post-container grid-layout">
					<div class="blog-post-inner">
						<?php if ( has_post_thumbnail() ) { ?>
							<div class="blog-post-image">
								<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'post-thumbnail' ); ?></a>
							</div>
						<?php } ?>
						<div class="blog-post-detail">
							<div class="post-categories">
								<?php classica_press_categories_list(); ?>
							</div>
							<h2 class="entry-title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>
							<div class="post-meta">
								<?php classica_press_posted_by(); ?>
								<?php classica_press_posted_on(); ?>
							</div>
							<p class="post-excerpt">
								<?php echo wp_kses_post( wp_trim_words( get_the_content(), 20 ) ); ?>
							</p>
						</div>
					</div>
				</div>
				<?php
			endwhile;
			wp_reset_postdata();
		}
		?>
	</div>
</div>
