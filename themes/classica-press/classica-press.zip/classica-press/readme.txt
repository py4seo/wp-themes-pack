=== Classica Press ===

Contributors: ascendoor
Tags: custom-background, custom-logo, custom-colors, custom-menu, featured-images, threaded-comments, translation-ready, theme-options, footer-widgets, full-width-template, left-sidebar, right-sidebar, news, blog
Requires at least: 5.0
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Classica Press is a stylish WordPress theme with a timeless black-and-white design, perfect for news, magazine, and portal websites. Its classic layout, clean typography, and minimalist style put your content at the center, creating a professional and elegant reading experience. Fully responsive and SEO-friendly, this theme combines performance with sophistication, making it ideal for publishers, bloggers, and journalists who want a modern site with a classic touch. Explore the theme documentation at https://docs.ascendoor.com/docs/classica-press/ and view the demo at https://demos.ascendoor.com/classica-press/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

The theme is integrated to work with following plugins:
* One Click Demo Import: This plugin is recommended to use for demo importing purpose.
* Contact Form 7: This plugin is recommended to use for contact forms on contact page.

== Changelog ==

= 1.0.0 =
* Initial release

== Images Screenshot ==

https://pxhere.com/en/photo/869535
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/752204
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/1217211
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/611730
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/114785
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/456016
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/1248352
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

https://pxhere.com/en/photo/718729
[Creative Commons Zero (CC0) License] 
https://pxhere.com/en/license

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2018 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
* class-tgm-plugin-activation.php https://github.com/TGMPA/TGM-Plugin-Activation [GNU General Public License v2.0]
* Breadcrumb Trail: https://github.com/justintadlock/breadcrumb-trail, [GNU General Public License v2.0]
* Slick: https://github.com/kenwheeler/slick/, (c) 2017 Ken Wheeler, License: MIT license
* jQuery.Marquee: https://github.com/aamirafridi/jQuery.Marquee/blob/master/licence, (c) 2017 Aamir Afridi http://www.aamirafridi.com, License: MIT license
* Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com, License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License)
* Google Fonts: https://fonts.google.com/, License: Apache License, version 2.0
* Webfonts Loader: https://github.com/WPTT/webfont-loader, License: MIT, https://github.com/WPTT/webfont-loader/blob/master/LICENSE