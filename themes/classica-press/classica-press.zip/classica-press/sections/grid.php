<?php
if ( ! get_theme_mod( 'classica_press_enable_grid_section', false ) ) {
	return;
}

$grid_content_ids  = array();
$grid_content_type = get_theme_mod( 'classica_press_grid_content_type', 'post' );

if ( $grid_content_type === 'post' ) {
	for ( $i = 1; $i <= 4; $i++ ) {
		$grid_content_ids[] = get_theme_mod( 'classica_press_grid_content_post_' . $i );
	}
	$grid_args = array(
		'post_type'           => 'post',
		'posts_per_page'      => absint( 4 ),
		'ignore_sticky_posts' => true,
	);
	if ( ! empty( array_filter( $grid_content_ids ) ) ) {
		$grid_args['post__in'] = array_filter( $grid_content_ids );
		$grid_args['orderby']  = 'post__in';
	} else {
		$grid_args['orderby'] = 'date';
	}
} else {
	$cat_content_id = get_theme_mod( 'classica_press_grid_content_category' );
	$grid_args      = array(
		'cat'            => $cat_content_id,
		'posts_per_page' => absint( 4 ),
	);
}
$grid_args = apply_filters( 'classica_press_grid_section_args', $grid_args );

classica_press_render_grid_section( $grid_args );

/**
 * Render Grid Section.
 */
function classica_press_render_grid_section( $grid_args ) {

	$query = new WP_Query( $grid_args );
	if ( $query->have_posts() ) {
		$section_title       = get_theme_mod( 'classica_press_grid_title', __( 'Grid Posts', 'classica-press' ) );
		$view_all_button     = get_theme_mod( 'classica_press_grid_button_label', __( 'View All', 'classica-press' ) );
		$grid_content_type   = get_theme_mod( 'classica_press_grid_content_type', 'post' );
		$view_all_button_url = get_theme_mod( 'classica_press_grid_button_link' );
		if ( 'category' === $grid_content_type ) {
			$grid_posts_category = get_theme_mod( 'classica_press_grid_content_category' );
			$view_all_button_url = ! empty( $view_all_button_url ) ? $view_all_button_url : get_category_link( $grid_posts_category );
		} else {
			$view_all_button_url = ! empty( $view_all_button_url ) ? $view_all_button_url : '#';
		}

		?>
		<section id="classica_press_grid_section" class="grid-section section-splitter column-4">
			<?php
			if ( is_customize_preview() ) :
				classica_press_section_link( 'classica_press_grid_section' );
			endif;
			?>
			<div class="section-wrapper">
				<div class="main-wrap">
					<?php if ( ! empty( $section_title || $view_all_button ) ) : ?>
						<div class="title-heading">
							<h3 class="section-title">
								<?php echo esc_html( $section_title ); ?>
							</h3>
							<?php if ( ! empty( $view_all_button ) ) { ?>
								<a href="<?php echo esc_url( $view_all_button_url ); ?>" class="view-all"><?php echo esc_html( $view_all_button ); ?></a>
							<?php } ?>
						</div>
					<?php endif; ?>
					<div class="grid-wrap">
						<?php
						while ( $query->have_posts() ) :
							$query->the_post();
							?>
							<div class="blog-post-container grid-layout">
								<div class="blog-post-inner">
									<?php if ( has_post_thumbnail() ) { ?>
										<div class="blog-post-image">
											<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'post-thumbnail' ); ?></a>
										</div>
									<?php } ?>
									<div class="blog-post-detail">
										<div class="post-categories">
											<?php classica_press_categories_list(); ?>
										</div>
										<h2 class="entry-title">
											<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
										</h2>
										<div class="post-meta">
											<?php classica_press_posted_by(); ?>
											<?php classica_press_posted_on(); ?>
										</div>
										<p class="post-excerpt">
											<?php echo wp_kses_post( wp_trim_words( get_the_content(), 25 ) ); ?>
										</p>
									</div>
								</div>
							</div>
							<?php
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</div>
			</div>
		</section>
		<?php
	}
}
