<?php
if ( ! get_theme_mod( 'classica_press_enable_banner_section', false ) ) {
	return;
}

$main_banner_content_ids = $top_stories_content_ids = $editor_content_ids = array();
$banner_content_type     = get_theme_mod( 'classica_press_main_banner_content_type', 'post' );
$stories_content_type    = get_theme_mod( 'classica_press_top_stories_content_type', 'post' );
$editor_content_type     = get_theme_mod( 'classica_press_editor_choice_content_type', 'post' );

if ( $banner_content_type === 'post' ) {
	for ( $i = 1; $i <= 2; $i++ ) {
		$main_banner_content_ids[] = get_theme_mod( 'classica_press_main_banner_content_post_' . $i );
	}
	$main_banner_args = array(
		'post_type'           => 'post',
		'posts_per_page'      => absint( 2 ),
		'ignore_sticky_posts' => true,
	);
	if ( ! empty( array_filter( $main_banner_content_ids ) ) ) {
		$main_banner_args['post__in'] = array_filter( $main_banner_content_ids );
		$main_banner_args['orderby']  = 'post__in';
	} else {
		$main_banner_args['orderby'] = 'date';
	}
} else {
	$cat_content_id   = get_theme_mod( 'classica_press_main_banner_content_category' );
	$main_banner_args = array(
		'cat'            => $cat_content_id,
		'posts_per_page' => absint( 2 ),
	);
}
$main_banner_args = apply_filters( 'classica_press_banner_section_args', $main_banner_args );

if ( $stories_content_type === 'post' ) {
	for ( $i = 1; $i <= 2; $i++ ) {
		$top_stories_content_ids[] = get_theme_mod( 'classica_press_top_stories_content_post_' . $i );
	}
	$stories_args = array(
		'post_type'           => $stories_content_type,
		'posts_per_page'      => absint( 2),
		'ignore_sticky_posts' => true,
	);
	if ( ! empty( array_filter( $top_stories_content_ids ) ) ) {
		$stories_args['post__in'] = array_filter( $top_stories_content_ids );
		$stories_args['orderby']  = 'post__in';
	} else {
		$stories_args['orderby'] = 'date';
	}
} else {
	$cat_content_id = get_theme_mod( 'classica_press_top_stories_content_category' );
	$stories_args   = array(
		'cat'            => $cat_content_id,
		'posts_per_page' => absint( 2),
	);
}
$stories_args = apply_filters( 'classica_press_banner_section_args', $stories_args );

if ( $editor_content_type === 'post' ) {
	for ( $i = 1; $i <= 3; $i++ ) {
		$editor_content_ids[] = get_theme_mod( 'classica_press_editor_choice_content_post_' . $i );
	}
	$editor_args = array(
		'post_type'           => 'post',
		'posts_per_page'      => absint( 3 ),
		'ignore_sticky_posts' => true,
	);
	if ( ! empty( array_filter( $editor_content_ids ) ) ) {
		$editor_args['post__in'] = array_filter( $editor_content_ids );
		$editor_args['orderby']  = 'post__in';
	} else {
		$editor_args['orderby'] = 'date';
	}
} else {
	$cat_content_id = get_theme_mod( 'classica_press_editor_choice_content_category' );
	$editor_args    = array(
		'cat'            => $cat_content_id,
		'posts_per_page' => absint( 3 ),
	);
}
$editor_args = apply_filters( 'classica_press_banner_section_args', $editor_args );

classica_press_render_banner_section( $main_banner_args, $stories_args, $editor_args );

/**
 * Render Banner Section.
 */
function classica_press_render_banner_section( $main_banner_args, $stories_args, $editor_args ) {
	?>

	<section id="classica_press_banner_section" class="magazine-banner section-splitter banner-style-1">
		<?php
		if ( is_customize_preview() ) :
			classica_press_section_link( 'classica_press_banner_section' );
		endif;
		?>
		<div class="section-wrapper">
			<div class="banner-container-wrapper">
				<div class="banner-wrapper">
					<?php
					require get_template_directory() . '/template-parts/sections/banner/main-banner.php';

					require get_template_directory() . '/template-parts/sections/banner/top-stories.php';

					require get_template_directory() . '/template-parts/sections/banner/editors-choice.php';

					?>
				</div>
			</div>
		</div>
	</section>

	<?php
}
