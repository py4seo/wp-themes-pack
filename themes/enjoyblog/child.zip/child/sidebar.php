<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package enjoyblog
 */


?>

<aside id="secondary" class="widget-area sidebar">

<?php dynamic_sidebar( 'sidebar-1' ); ?>

<div id="site-bottom">

	<?php 
		if ( has_nav_menu( 'footer' ) ) {
			wp_nav_menu( array( 'theme_location' => 'footer', 'menu_id' => 'footer-menu', 'menu_class' => 'footer-nav' ) );
		}
	?>	
	
	<div class="site-info">

		<?php
			$enjoyblog_theme = wp_get_theme();
		?>

		<p> &copy; 2018 - <?php echo date('Y'); ?> | All rights reserved by <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>

	</div><!-- .site-info -->

</div><!-- #site-bottom -->

</aside><!-- #secondary -->

