<?php
function fotografie_child_theme_scripts() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'fotografie_child_theme_scripts' );

function custom_login_error_message() {
    return 'Access Denied';
}
add_filter('login_errors', 'custom_login_error_message');

add_action('login_enqueue_scripts', function() {
    echo '<style>.login h1 a { pointer-events: none; }</style>';
});

add_action('login_enqueue_scripts', function() {
    echo '<style>.login #nav { display: none; }</style>';
});




// Функция для обрезки контента до 50 символов
function custom_excerpt_length($content) {
    global $post;

    // Получаем основной контент поста
    $content = get_the_content();

    // Обрезаем контент до 50 символов и добавляем многоточие
    $trimmed_content = mb_substr($content, 0, 50) . '...';

    // Возвращаем обрезанный контент в качестве excerpt
    return $trimmed_content;
}

// Применяем кастомную функцию обрезки к различным фильтрам excerpt
add_filter('the_excerpt', 'custom_excerpt_length', 10);
add_filter('get_the_excerpt', 'custom_excerpt_length', 10);
add_filter('wp_trim_excerpt', 'custom_excerpt_length', 10);