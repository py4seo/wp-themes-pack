=== Twelve Blog ===

Contributors: kantipurthemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, one-column, two-columns, custom-header, blog, entertainment, portfolio
Requires at least: 5.1
Requires PHP: 5.6
Tested up to: 6.5
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Twelve Blog is a simple blogging wordpress theme that can be used for blog sites like fashion blog, lifestyle blog, travel blog, nature blog, food blog etc.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Twelve Blog WordPress Theme, Copyright 2022 Kantipur Themes
Twelve Blog is distributed under the terms of the GNU GPL

== Changelog ==

= 1.1 - May 27, 2024 =
* Updated design

= 1.0 - July 21 2022 =
* Initial release

== Resources ==

Screenshot Image Link
License: CC0 1.0 Universal (CC0 1.0)
https://pxhere.com/en/photo/1620892

normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal
License: MIT
Source: https://necolas.github.io/normalize.css/

Underscores, Copyright 2012-2017 Automattic
License: GPLv2 or later
Source: https://www.gnu.org/licenses/gpl-2.0.html

SVG Icons, Copyright 2016 WordPress.org ( https://github.com/WordPress/twentyseventeen )
License: GPLv2 or later
Source: http://www.gnu.org/licenses/gpl-2.0.html

Customizer Pro, Copyright 2016 © Justin Tadlock
License: GPLv2 or later
Source: https://github.com/justintadlock/trt-customizer-pro